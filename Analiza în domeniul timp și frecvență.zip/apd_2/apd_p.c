#include <analysis.h>
#include <ansi_c.h>
#include <utility.h>
#include <formatio.h>
#include <cvirte.h>		
#include <userint.h>
#include "apd_p.h"		

#define SAMPLE_RATE		0
#define NPOINTS			1
#define INTERVAL_SIZE   256

int waveInfo[2]; //waveInfo[0] = sampleRate
				 //waveInfo[1] = number of elements
double sampleRate = 0.0;
int npoints = 0;
double *waveData = 0;
double *waveDat=0;
static int panelHandle;
static int freqPanel;
int intervalCurent=0;
double *anvelopa=0;
int tipFiltru;
int tipAfisare;
int nrFereastra; //fereastra curenta pentru afisarea pe numarul de puncte
int numarFerestre;
double rate = 0;
int tipFereastra;
int secunda;
double *waveDataPerNrPuncte;
double *wavepersec;
int numarpuncte;
double* semnalFiltrat=0;
double* semnalFF=0;

void aplicareFiltru(int panel);
void aplicareFereastra(int panel);
void afisareSpectru(int panel);
void afispesecunde(int panel);
void afisSemnalIntreg(int panel);

int comparare(const void *a, const void *b) {
    double fa = *(const double*)a;
    double fb = *(const double*)b;
    if (fa < fb) return -1;
    if (fa > fb) return 1;
    return 0;
}
void FiltrareOrdin1(double signal[], double filt[], int length, double alpha) 
{
    filt[0] = signal[0];
    for (int i = 1; i < length; i++) {
        filt[i] = (1 - alpha) * filt[i - 1] + alpha * signal[i];
    }
}
void FiltrarePrinMediere(double semnal[], double filt[], int lung, int window_size) 
{
    for (int i = 0; i < lung; i++) {
        double sum = 0.0;
        int nr = 0;
        for (int j = i - window_size / 2; j <= i + window_size / 2; j++) {
            if (j >= 0 && j < lung) {
                sum += semnal[j];
                nr++;
            }
        }
        filt[i] = sum / nr;
    }
}
double Medie(double data[],int lung)
{
	double sum=0.0;
	for(int i=0;i<lung;i++)
		sum+=data[i];
	return sum/lung;
}
double CalculareSkewness(double data[], int lung) {
    double medie = Medie(data, lung);
    double sum3 = 0, sum2 = 0;
    for (int i = 0; i < lung; i++) {
        double deviatie = data[i] - medie;
        sum3 += pow(deviatie, 3);
        sum2 += pow(deviatie, 2);
    }
    if (sum2 == 0) return 0;
    double numarator = sum3 / lung;
    double numitor = pow(sum2 / lung, 1.5);
    return numarator / numitor;
}

double CalculareKurtosis(double data[], int lung) {
    double medie = Medie(data, lung);
    double sum4 = 0, sum2 = 0;
    for (int i = 0; i < lung; i++) {
        double deviatie = data[i] - medie;
        sum4 += pow(deviatie, 4);
        sum2 += pow(deviatie, 2);
    }
    if (sum2 == 0) return 0;
    double numarator = sum4 / lung;
    double numitor = pow(sum2 / lung, 2.0);
    return numarator / numitor;
}
void IncarcareAnvelopa(const char *filename)
{
	FILE *file=fopen(filename,"r");
	if(file==NULL)
	{
		return;
	}
	anvelopa=(double*)calloc(npoints,sizeof(double));
	if(anvelopa==NULL)
	{
		fclose(file);
		return;
	}
	for(int i=0;i<npoints;i++)
	{
		if(fscanf(file,"%lf",&anvelopa[i])!=1)
		{
			free(anvelopa);
			anvelopa=0;
			fclose(file);
			return;
		}
	}
	fclose(file);
}
void SalveazaImagine(int panel, int panelId,const char *numeFisier)
{
	int bitmapID;
	GetCtrlDisplayBitmap(panel,panelId,1,&bitmapID);
	SaveBitmapToJPEGFile(bitmapID,numeFisier,JPEG_PROGRESSIVE,100);
	DiscardBitmap(bitmapID);
}
void DerivataSemnal(double semnal[], double derivata[], int lung, double rata) {
    for (int i = 1; i < lung; i++) {
        derivata[i - 1] = (semnal[i] - semnal[i - 1]) * rata;
    }
    derivata[lung - 1] = derivata[lung - 2];
}
void UpdateIntervalDisplay() {
    int start = intervalCurent * INTERVAL_SIZE;
    int end = start + INTERVAL_SIZE;
    if (end > npoints) end = npoints;
    int lungime = end - start;

    if (lungime <= 0) {
        return;
    }

    double *segment = &waveData[start];
	double *segmentAnvelopa = &anvelopa[start];
	
    double skewness1 = CalculareSkewness(segment, lungime);
    double kurtosis1 = CalculareKurtosis(segment, lungime);

    char skewnessStr1[50], kurtosisStr1[50];
    sprintf(skewnessStr1, "%.2f", skewness1);
    sprintf(kurtosisStr1, "%.2f", kurtosis1);

    SetCtrlVal(panelHandle, PANEL_SKEWNESS1, skewnessStr1);
    SetCtrlVal(panelHandle, PANEL_KURTOSIS1, kurtosisStr1);

    DeleteGraphPlot(panelHandle, PANEL_GRAPH, -1, VAL_IMMEDIATE_DRAW);
    PlotY(panelHandle, PANEL_GRAPH, segment, lungime, VAL_DOUBLE, VAL_THIN_LINE, VAL_EMPTY_SQUARE, VAL_SOLID, VAL_CONNECTED_POINTS, VAL_RED);
	PlotY(panelHandle, PANEL_GRAPH, segmentAnvelopa, lungime, VAL_DOUBLE, VAL_THIN_LINE, VAL_EMPTY_SQUARE, VAL_SOLID, VAL_CONNECTED_POINTS, VAL_BLUE);
  
	 int optiune;
     GetCtrlVal(panelHandle, PANEL_RING_2, &optiune);
     int filterType;
     GetCtrlVal(panelHandle, PANEL_RING, &filterType);

     double alpha;
     GetCtrlVal(panelHandle, PANEL_alpha, &alpha);

     int window_size;
     GetCtrlVal(panelHandle, PANEL_window_size, &window_size);

     double *procesata = (double *)calloc(lungime, sizeof(double));

     if (optiune == 0) { 
         if (filterType == 0) {
              FiltrareOrdin1(segment, procesata, lungime, alpha);
         } else {
              FiltrarePrinMediere(segment, procesata, lungime, window_size);
      	}
     } else { 
            DerivataSemnal(segment, procesata, lungime, sampleRate);
     }

     DeleteGraphPlot(panelHandle, PANEL_FILTRU, -1, VAL_IMMEDIATE_DRAW);
     PlotY(panelHandle, PANEL_FILTRU, procesata, lungime, VAL_DOUBLE, VAL_THIN_LINE, VAL_EMPTY_SQUARE, VAL_SOLID, VAL_CONNECTED_POINTS, VAL_YELLOW);

     free(procesata);

   
    char filenameOriginal[100];
    sprintf(filenameOriginal, "ProiectAPD\\grafic_original_%d.jpg", intervalCurent);
    SalveazaImagine(panelHandle, PANEL_GRAPH, filenameOriginal);

    char filenameFiltrat[100];
    sprintf(filenameFiltrat, "ProiectAPD\\grafic_filtrat_%d.jpg", intervalCurent);
    SalveazaImagine(panelHandle, PANEL_FILTRU, filenameFiltrat);
	
	double Min=segment[0];
	double Max=segment[0];
	double indexMin=0;
	double indexMax=0;
	double sum=segment[0];
		
	for(int i=1;i<lungime;i++)
	{
		sum+=segment[i];
		if(Min>segment[i])
		{
			Min=segment[i];
			indexMin=i;
		}
		if(Max<segment[i])
		{
			Max=segment[i];
			indexMax=i;
		}
	}
	double med=(double)sum/lungime;
	double dispersie = 0;
	for (int i = 0; i < lungime; i++) {
    		dispersie += pow(segment[i] - med, 2);
	}
	dispersie /= lungime;
	char medie[50];
	char minStr[50], maxStr[50];
	char minIndex[50], maxIndex[50];
			  
	sprintf(minStr, "%.2f", Min);  
    sprintf(maxStr, "%.2f", Max); 
	sprintf(minIndex, "%.2f", indexMin);
	sprintf(maxIndex, "%.2f", indexMax);
	sprintf(medie, "%.2f", med);
    SetCtrlVal(panelHandle, PANEL_MIN, minStr); 
    SetCtrlVal(panelHandle, PANEL_MAX, maxStr);
	SetCtrlVal(panelHandle, PANEL_IndexMin, minIndex); 
	SetCtrlVal(panelHandle, PANEL_IndexMax, maxIndex); 
	SetCtrlVal(panelHandle, PANEL_MEDIE, medie);
	char dispersieStr[50];
	sprintf(dispersieStr, "%.2f", dispersie);
	SetCtrlVal(panelHandle, PANEL_DISPERSIE, dispersieStr);
			
	int treceriZero = 0;

	for (int i = 1; i < lungime; i++) {
    	if ((segment[i-1] < 0 && segment[i] > 0) || (segment[i-1] > 0 && segment[i] < 0)) {
       			treceriZero++;
    	}
	}

	char treceriZeroStr[50];
	sprintf(treceriZeroStr, "%d", treceriZero);
	SetCtrlVal(panelHandle, PANEL_TRECERI_ZERO, treceriZeroStr);
			
	double *sortata = (double *)malloc(lungime * sizeof(double));
	memcpy(sortata, segment, lungime * sizeof(double));
	qsort(sortata, lungime, sizeof(double), comparare);

	double mediana;
	if (lungime % 2 == 0) {
   			mediana = (sortata[lungime / 2 - 1] + sortata[lungime / 2]) / 2.0;
	} else {
    		mediana = sortata[lungime / 2];
	}
	
	double interval=(Max-Min)/20.0;
	int histograma[20]={0};
	for(int i=0;i<lungime;i++)
	{
		int index=(int)(segment[i]-Min)/interval;
		if(index >=0 && index<20)
			histograma[index]++;
	}
	DeleteGraphPlot(panelHandle, PANEL_HISTOGRAMA, -1, VAL_IMMEDIATE_DRAW);
	PlotY(panelHandle,PANEL_HISTOGRAMA,histograma,20,VAL_INTEGER,VAL_VERTICAL_BAR,VAL_EMPTY_SQUARE,VAL_SOLID,VAL_CONNECTED_POINTS,VAL_YELLOW);
	free(sortata);
	char medianaStr[50];
	sprintf(medianaStr, "%.2f", mediana);
	SetCtrlVal(panelHandle, PANEL_MEDIANA, medianaStr);
}

int main (int argc, char *argv[])
{
	if (InitCVIRTE (0, argv, 0) == 0)
		return -1;	/* out of memory */
	if ((panelHandle = LoadPanel (0, "apd_p.uir", PANEL)) < 0)
		return -1;
	if((freqPanel = LoadPanel (0, "apd_p.uir", FREQ_PANEL))<0)
		return -1;
	SetCtrlAttribute(freqPanel, FREQ_PANEL_TIMER, ATTR_ENABLED, 0); // Dezactivam timerul la pornire
	DisplayPanel (panelHandle);
	RunUserInterface ();
	DiscardPanel (panelHandle);
	free(waveData);  
	return 0;
}

int CVICALLBACK ApplyFilter (int panel, int control, int event, void *callbackData, int eventData1, int eventData2) {
    if (event == EVENT_COMMIT) {
        int optiune;
        GetCtrlVal(panel, PANEL_RING_2, &optiune);
        int filterType;
        GetCtrlVal(panel, PANEL_RING, &filterType);

        double alpha;
        GetCtrlVal(panel, PANEL_alpha, &alpha);

        int window_size;
        GetCtrlVal(panel, PANEL_window_size, &window_size);

        double *procesata = (double *)calloc(npoints, sizeof(double));

        if (optiune == 0) { 
            if (filterType == 0) {
                FiltrareOrdin1(waveData, procesata, npoints, alpha);
            } else {
                FiltrarePrinMediere(waveData, procesata, npoints, window_size);
            }
        } else { 
            DerivataSemnal(waveData, procesata, npoints, sampleRate);
        }

        DeleteGraphPlot(panel, PANEL_FILTRU, -1, VAL_IMMEDIATE_DRAW);
        PlotY(panel, PANEL_FILTRU, procesata, npoints, VAL_DOUBLE, VAL_THIN_LINE, VAL_EMPTY_SQUARE, VAL_SOLID, VAL_CONNECTED_POINTS, VAL_YELLOW);

        free(procesata);
    }
    return 0;
}

int CVICALLBACK LoadButton (int panel, int control, int event,
								void *callbackData, int eventData1, int eventData2)
{
	
	switch (event)
	{
		case EVENT_COMMIT:
			//executa script python pentru conversia unui fisierului .wav in .txt
		//	LaunchExecutable("python main.py");
			
			//astept sa fie generate cele doua fisiere (modificati timpul daca este necesar
			//Delay(4);
			
			//incarc informatiile privind rata de esantionare si numarul de valori
			FileToArray("wafeInfo.txt", waveInfo, VAL_INTEGER, 2, 1, VAL_GROUPS_TOGETHER, VAL_GROUPS_AS_COLUMNS, VAL_ASCII);
			sampleRate = waveInfo[SAMPLE_RATE];
			npoints = waveInfo[NPOINTS];
			waveData = (double *) calloc(npoints, sizeof(double));   
			//alocare memorie pentru numarul de puncte
			FileToArray("waveData.txt", waveData, VAL_DOUBLE, npoints, 1, VAL_GROUPS_TOGETHER, VAL_GROUPS_AS_COLUMNS, VAL_ASCII);
			waveDat=waveData;
			if (!waveData) {
    printf("Eroare: Memoria pentru waveData nu a fost alocata.\n");
    return -1;
}
			if (npoints <= 0) {
    printf("Eroare: Numar de puncte invalid (%d).\n", npoints);
    return -1;
}

			IncarcareAnvelopa("anvelopa.txt");
            if (!anvelopa) {
                return -1;
            }
			DeleteGraphPlot(panel, PANEL_GRAPH, -1, VAL_IMMEDIATE_DRAW);
            PlotY(panel, PANEL_GRAPH, waveData, npoints, VAL_DOUBLE, VAL_THIN_LINE, VAL_EMPTY_SQUARE, VAL_SOLID, VAL_CONNECTED_POINTS, VAL_RED);
            PlotY(panel, PANEL_GRAPH, anvelopa, npoints, VAL_DOUBLE, VAL_THIN_LINE, VAL_EMPTY_SQUARE, VAL_SOLID, VAL_CONNECTED_POINTS, VAL_BLUE);
			double Min=waveData[0];
			double Max=waveData[0];
			double indexMin=0;
			double indexMax=0;
			double sum=waveData[0];
		
			 for(int i=1;i<npoints;i++)
			 {
				 sum+=waveData[i];
				 if(Min>waveData[i])
				 {
					 Min=waveData[i];
					 indexMin=i;
				 }
				 if(Max<waveData[i])
				 {
					 Max=waveData[i];
					 indexMax=i;
				 }
			 }
			 double med=(double)sum/npoints;
			 double dispersie = 0;
			for (int i = 0; i < npoints; i++) {
    				dispersie += pow(waveData[i] - med, 2);
			}
			  dispersie /= npoints;
			 char medie[50];
			 char minStr[50], maxStr[50];
			  char minIndex[50], maxIndex[50];
			  
		    sprintf(minStr, "%.2f", Min);  
            sprintf(maxStr, "%.2f", Max); 
			sprintf(minIndex, "%.2f", indexMin);
			sprintf(maxIndex, "%.2f", indexMax);
			sprintf(medie, "%.2f", med);
            SetCtrlVal(panel, PANEL_MIN, minStr); 
            SetCtrlVal(panel, PANEL_MAX, maxStr);
			SetCtrlVal(panel, PANEL_IndexMin, minIndex); 
			SetCtrlVal(panel, PANEL_IndexMax, maxIndex); 
			SetCtrlVal(panel, PANEL_MEDIE, medie);
			char dispersieStr[50];
			sprintf(dispersieStr, "%.2f", dispersie);
			SetCtrlVal(panel, PANEL_DISPERSIE, dispersieStr);
			
			int treceriZero = 0;

			for (int i = 1; i < npoints; i++) {
    			if ((waveData[i-1] < 0 && waveData[i] > 0) || (waveData[i-1] > 0 && waveData[i] < 0)) {
       					 treceriZero++;
    			}
			}

			char treceriZeroStr[50];
			sprintf(treceriZeroStr, "%d", treceriZero);
			SetCtrlVal(panel, PANEL_TRECERI_ZERO, treceriZeroStr);
			
			double *sortedWaveData = (double *)malloc(npoints * sizeof(double));
			memcpy(sortedWaveData, waveData, npoints * sizeof(double));
			qsort(sortedWaveData, npoints, sizeof(double), comparare);

			double mediana;
			if (npoints % 2 == 0) {
   					mediana = (sortedWaveData[npoints / 2 - 1] + sortedWaveData[npoints / 2]) / 2.0;
			} else {
    				mediana = sortedWaveData[npoints / 2];
			}

			free(sortedWaveData);
			char medianaStr[50];
			sprintf(medianaStr, "%.2f", mediana);
			SetCtrlVal(panel, PANEL_MEDIANA, medianaStr); 

			double interval=(Max-Min)/20.0;
			int histograma[20]={0};
			for(int i=0;i<npoints;i++)
			{
				int index=(int)(waveData[i]-Min)/interval;
				if(index >=0 && index<20)
					histograma[index]++;
			}
			PlotY(panel,PANEL_HISTOGRAMA,histograma,20,VAL_INTEGER,VAL_VERTICAL_BAR,VAL_EMPTY_SQUARE,VAL_SOLID,VAL_CONNECTED_POINTS,VAL_YELLOW);
			break;
	}
	return 0;
}



int CVICALLBACK PrevButton (int panel, int control, int event,
							void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			if(intervalCurent>0)
			{
				intervalCurent--;
				UpdateIntervalDisplay();
			}
			break;
	}
	return 0;
}

int CVICALLBACK NextButton (int panel, int control, int event,
							void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			if((intervalCurent+1)*INTERVAL_SIZE<npoints)
			{
				intervalCurent++;
				UpdateIntervalDisplay();
			}
		
			break;
	}
	return 0;
}

int CVICALLBACK OnSwitchPanelCB(int panel, int control, int event, void *callbackData, int eventData1, int eventData2) {
    switch (event) {
        case EVENT_COMMIT:

            if (panel == panelHandle) {
                SetCtrlVal(freqPanel, FREQ_PANEL_SWITCH_PANEL, 1);
                DisplayPanel(freqPanel);
                HidePanel(panel);
                SetCtrlAttribute(freqPanel, FREQ_PANEL_TIMER, ATTR_ENABLED, 1); // pornim timer ul
            } else {
                SetCtrlVal(panelHandle, PANEL_SWITCH_PANEL, 1);
                DisplayPanel(panelHandle);
                HidePanel(panel);
                SetCtrlAttribute(freqPanel, FREQ_PANEL_TIMER, ATTR_ENABLED, 0); // oprim timer ul
            }
            break;
    }
    return 0;
}
int CVICALLBACK OnFrequencyPanel (int panel, int event, void *callbackData,
								  int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_GOT_FOCUS:

			break;
		case EVENT_LOST_FOCUS:

			break;
		case EVENT_CLOSE:

			QuitUserInterface(0);
			break;
	}
	return 0;
}

int CVICALLBACK WindowType (int panel, int control, int event,
							  void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			aplicareFereastra(panel); //aplicam tipul de fereastra
			
			
			break;
	}
	return 0;
}
int CVICALLBACK SecondFrequency (int panel, int control, int event,
							   void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			afispesecunde(panel);  //afisam pe o anumita secunda
			break;
	}
	return 0;
}
int CVICALLBACK OnFilterType (int panel, int control, int event,
								  void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			aplicareFiltru(panel);   //aplicam filtrul
			break;
	}
	return 0;
}

int CVICALLBACK OnShow (int panel, int control, int event,
						void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
	
			GetCtrlVal(panel, FREQ_PANEL_TIP_AFISARE, &tipAfisare);

			if(tipAfisare==0)
			{
				nrFereastra=0;
				SetCtrlAttribute(panel,FREQ_PANEL_TIMER, ATTR_ENABLED,1);
				SetCtrlAttribute(panel,FREQ_PANEL_BUFFER_SIZE,ATTR_DIMMED,0);
				SetCtrlAttribute(panel,FREQ_PANEL_SECOND,ATTR_DIMMED,1);
			}
			else
				if(tipAfisare==1)
				{
					SetCtrlAttribute(panel,FREQ_PANEL_TIMER, ATTR_ENABLED,0);
					SetCtrlAttribute(panel,FREQ_PANEL_BUFFER_SIZE,ATTR_DIMMED,1);
					SetCtrlAttribute(panel,FREQ_PANEL_SECOND,ATTR_DIMMED,1);
					afisSemnalIntreg(panel);
				}
			else
				if(tipAfisare==2)
				{
					SetCtrlAttribute(panel,FREQ_PANEL_TIMER, ATTR_ENABLED,0);
					SetCtrlAttribute(panel,FREQ_PANEL_BUFFER_SIZE,ATTR_DIMMED,1);
					SetCtrlAttribute(panel,FREQ_PANEL_SECOND,ATTR_DIMMED,0);
					afispesecunde(panel);
				}
			break;
	}
	return 0;
}
void aplicareFiltru(int panel) {
    GetCtrlAttribute(panel, FREQ_PANEL_FILTER_TYPE, ATTR_CTRL_INDEX, &tipFiltru);
    printf("tipul afisarii este %d\n", tipAfisare);
    double freqCutoff = sampleRate / 3.0;
    double freqPass = freqCutoff / 2.0;

    if (tipAfisare == 0) { 
        semnalFiltrat = (double *)malloc(numarpuncte * numarFerestre * sizeof(double));
        if (tipFiltru == 0) {
            if (freqCutoff > sampleRate / 2.0) {
                printf("Ajustare freqCutoff: %.2f depa?e?te limita Nyquist (%.2f).\n", freqCutoff, sampleRate / 2.0);
                freqCutoff = sampleRate / 2.0;
            }

            printf("Parametri Bw_BPF:\n");
            printf("Dimensiunea semnalului: %d\n", numarpuncte * numarFerestre);
            printf("sampleRate = %f\n", sampleRate);
            printf("freqPass = %f\n", freqPass);
            printf("freqCutoff = %f\n", freqCutoff);
            printf("Ordinul = %d\n", 6);

            Bw_BPF(waveDataPerNrPuncte, numarpuncte * numarFerestre, sampleRate, freqPass, freqCutoff, 6, semnalFiltrat);

            DeleteGraphPlot(panel, FREQ_PANEL_GRAPH_SF, -1, VAL_IMMEDIATE_DRAW);

            PlotY(panel, FREQ_PANEL_GRAPH_SF, semnalFiltrat + nrFereastra * numarpuncte, numarpuncte, VAL_DOUBLE, VAL_THIN_LINE, VAL_EMPTY_SQUARE, VAL_SOLID, VAL_CONNECTED_POINTS, VAL_RED);
            aplicareFereastra(panel);
        } else if (tipFiltru == 1) {
            if (freqCutoff > sampleRate / 2.0) {
                printf("Ajustare freqCutoff: %.2f depa?e?te limita Nyquist (%.2f).\n", freqCutoff, sampleRate / 2.0);
                freqCutoff = sampleRate / 2.0;
            }
            double ripple = 1;

            Ch_BPF(waveDataPerNrPuncte, numarpuncte * numarFerestre, sampleRate, freqPass, freqCutoff, 4, ripple, semnalFiltrat);

            DeleteGraphPlot(panel, FREQ_PANEL_GRAPH_SF, -1, VAL_IMMEDIATE_DRAW);

            PlotY(panel, FREQ_PANEL_GRAPH_SF, semnalFiltrat + nrFereastra * numarpuncte, numarpuncte, VAL_DOUBLE, VAL_THIN_LINE, VAL_EMPTY_SQUARE, VAL_SOLID, VAL_CONNECTED_POINTS, VAL_RED);
            aplicareFereastra(panel);
        }
    } else if (tipAfisare == 1) {
        semnalFiltrat = (double *)malloc(npoints * sizeof(double));
        if (tipFiltru == 0) {
            Bw_BPF(waveData, npoints, sampleRate, freqPass, freqCutoff, 6, semnalFiltrat);

            DeleteGraphPlot(panel, FREQ_PANEL_GRAPH_SF, -1, VAL_IMMEDIATE_DRAW);

            PlotY(panel, FREQ_PANEL_GRAPH_SF, semnalFiltrat, npoints, VAL_DOUBLE, VAL_THIN_LINE, VAL_EMPTY_SQUARE, VAL_SOLID, VAL_CONNECTED_POINTS, VAL_RED);
            aplicareFereastra(panel);
        } else if (tipFiltru == 1) {
            double ripple = 1;

            Ch_BPF(waveData, npoints, sampleRate, freqPass, freqCutoff, 4, ripple, semnalFiltrat);
            DeleteGraphPlot(panel, FREQ_PANEL_GRAPH_SF, -1, VAL_IMMEDIATE_DRAW);

            PlotY(panel, FREQ_PANEL_GRAPH_SF, semnalFiltrat, npoints, VAL_DOUBLE, VAL_THIN_LINE, VAL_EMPTY_SQUARE, VAL_SOLID, VAL_CONNECTED_POINTS, VAL_RED);
            aplicareFereastra(panel);
        }
    } else if (tipAfisare == 2) {
        semnalFiltrat = (double *)malloc(npoints / 6 * sizeof(double));
        if (tipFiltru == 0) { 
            Bw_BPF(wavepersec, npoints / 6, sampleRate, freqPass, freqCutoff, 6, semnalFiltrat);

            DeleteGraphPlot(panel, FREQ_PANEL_GRAPH_SF, -1, VAL_IMMEDIATE_DRAW);

            PlotY(panel, FREQ_PANEL_GRAPH_SF, semnalFiltrat, npoints / 6, VAL_DOUBLE, VAL_THIN_LINE, VAL_EMPTY_SQUARE, VAL_SOLID, VAL_CONNECTED_POINTS, VAL_RED);
            aplicareFereastra(panel);
        } else if (tipFiltru == 1) {
            double ripple = 1;

            Ch_BPF(wavepersec, npoints / 6, sampleRate, freqPass, freqCutoff, 4, ripple, semnalFiltrat);
            DeleteGraphPlot(panel, FREQ_PANEL_GRAPH_SF, -1, VAL_IMMEDIATE_DRAW);

            PlotY(panel, FREQ_PANEL_GRAPH_SF, semnalFiltrat, npoints / 6, VAL_DOUBLE, VAL_THIN_LINE, VAL_EMPTY_SQUARE, VAL_SOLID, VAL_CONNECTED_POINTS, VAL_RED);
            aplicareFereastra(panel);
        }
    }
}


void aplicareFereastra(int panel)
{
    GetCtrlAttribute(panel, FREQ_PANEL_WINDOW_TYPE, ATTR_CTRL_INDEX, &tipFereastra);
    double *fereastra;

    if (tipAfisare == 0) // pe numarul de puncte
    {
        semnalFF = (double *)malloc(numarpuncte * sizeof(double));
        fereastra = (double *)malloc(numarpuncte * sizeof(double));

        if (tipFereastra == 0) // Hamming
        {
            HamWin(fereastra, numarpuncte); 
        }
        else if (tipFereastra == 1) // Hanning
        {
            HanWin(fereastra, numarpuncte);
        }
        else // Fereastra dreptunghiulara (default)
        {
            for (int i = 0; i < numarpuncte; i++)
                fereastra[i] = 1.0;
        }

        DeleteGraphPlot(panel, FREQ_PANEL_GRAPH_FEREASTRA, -1, VAL_IMMEDIATE_DRAW);
        PlotY(panel, FREQ_PANEL_GRAPH_FEREASTRA, fereastra, numarpuncte, VAL_DOUBLE, VAL_THIN_LINE, VAL_EMPTY_SQUARE, VAL_SOLID, VAL_CONNECTED_POINTS, VAL_RED);

        if (tipFiltru != -1)
        {
            Mul1D(semnalFiltrat, fereastra, numarpuncte, semnalFF);
            DeleteGraphPlot(panel, FREQ_PANEL_GRAPH_FILTRAT, -1, VAL_IMMEDIATE_DRAW);
            PlotY(panel, FREQ_PANEL_GRAPH_FILTRAT, semnalFF, numarpuncte, VAL_DOUBLE, VAL_THIN_LINE, VAL_EMPTY_SQUARE, VAL_SOLID, VAL_CONNECTED_POINTS, VAL_RED);
            afisareSpectru(panel);
        }
    }
    else if (tipAfisare == 1) // tot semnalul
    {
        semnalFF = (double *)malloc(npoints * sizeof(double));
        fereastra = (double *)malloc(npoints * sizeof(double));
        if (tipFereastra == 0) // Hamming
        {
            for (int n = 0; n < npoints; n++) {
        fereastra[n] = 0.54 - 0.46 * cos((2.0 * 3.14 * n) / (npoints - 1));
    }
		}
        else if (tipFereastra == 1) // Hanning
        {
            for (int n = 0; n < npoints; n++) {
        fereastra[n] = 0.5 * (1 - cos(2 * 3.14 * n / (npoints - 1)));
    }
        }
        else // Fereastra dreptunghiulara (default)
        {
            for (int i = 0; i < npoints; i++)
                fereastra[i] = 1.0;
        }

        DeleteGraphPlot(panel, FREQ_PANEL_GRAPH_FEREASTRA, -1, VAL_IMMEDIATE_DRAW);
        PlotY(panel, FREQ_PANEL_GRAPH_FEREASTRA, fereastra, npoints, VAL_DOUBLE, VAL_THIN_LINE, VAL_EMPTY_SQUARE, VAL_SOLID, VAL_CONNECTED_POINTS, VAL_RED);


        if (tipFiltru != -1)
        {
            Mul1D(semnalFiltrat, fereastra, npoints, semnalFF);
            DeleteGraphPlot(panel, FREQ_PANEL_GRAPH_FILTRAT, -1, VAL_IMMEDIATE_DRAW);
            PlotY(panel, FREQ_PANEL_GRAPH_FILTRAT, semnalFF, npoints, VAL_DOUBLE, VAL_THIN_LINE, VAL_EMPTY_SQUARE, VAL_SOLID, VAL_CONNECTED_POINTS, VAL_RED);
        }
    }
    else if (tipAfisare == 2) // pe secunde
    {
        semnalFF = (double *)malloc(npoints / 6 * sizeof(double));
        fereastra = (double *)malloc(npoints / 6 * sizeof(double));
        if (tipFereastra == 0) // Hamming
        {
            HamWin(fereastra, npoints / 6);
        }
        else if (tipFereastra == 1) // Hanning
        {
            HanWin(fereastra, npoints / 6);
        }
        else // Fereastra dreptunghiulara (default)
        {
            for (int i = 0; i < npoints / 6; i++)
                fereastra[i] = 1.0;
        }

        DeleteGraphPlot(panel, FREQ_PANEL_GRAPH_FEREASTRA, -1, VAL_IMMEDIATE_DRAW);
        PlotY(panel, FREQ_PANEL_GRAPH_FEREASTRA, fereastra, npoints / 6, VAL_DOUBLE, VAL_THIN_LINE, VAL_EMPTY_SQUARE, VAL_SOLID, VAL_CONNECTED_POINTS, VAL_RED);

        if (tipFiltru != -1)
        {
            Mul1D(semnalFiltrat, fereastra, npoints / 6, semnalFF);
            DeleteGraphPlot(panel, FREQ_PANEL_GRAPH_FILTRAT, -1, VAL_IMMEDIATE_DRAW);
            PlotY(panel, FREQ_PANEL_GRAPH_FILTRAT, semnalFF, npoints / 6, VAL_DOUBLE, VAL_THIN_LINE, VAL_EMPTY_SQUARE, VAL_SOLID, VAL_CONNECTED_POINTS, VAL_RED);
        }
    }
}
 

void afisareSpectru(int panel)
{
	if(tipAfisare==0)//pe numarul de puncte
	{
			//spectru semnal filtrat si ferestruit
			double *convertedSpectrumsff=(double*)calloc(numarpuncte/2,sizeof(double));
			double *autoSpectrumsff=(double*)calloc(numarpuncte/2,sizeof(double));
			double dff=0.0;
			double powerPeak1=0.0;
			double freqPeak1=0.0;
			char unit[32]="";
			WindowConst winConst;
			
			ScaledWindowEx(semnalFF,numarpuncte,RECTANGLE_,0,&winConst);
			AutoPowerSpectrum(semnalFF,numarpuncte,1.0/sampleRate,autoSpectrumsff,&dff);
			double maxVal = 0.0;
			for (int i = 0; i < numarpuncte / 2; i++) {
    			if (autoSpectrumsff[i] > maxVal) {
        			maxVal = autoSpectrumsff[i];
    				}
			}
			for (int i = 0; i < numarpuncte / 2; i++) {
    			autoSpectrumsff[i] /= maxVal;
			}

			//calculeaza puterea si frecventa corespunzatoare varfului din spectrul semnalului 
			PowerFrequencyEstimate(autoSpectrumsff, numarpuncte / 2, -1.0, winConst, dff, 7, &freqPeak1, &powerPeak1);
			char freqPeakStr1[50], powerPeakStr1[50];
			sprintf(freqPeakStr1, "%.2f", freqPeak1);
			sprintf(powerPeakStr1, "%.2f", powerPeak1);
			SetCtrlVal(panel, FREQ_PANEL_FREQUENCY_PEAK_2, freqPeakStr1);
			SetCtrlVal(panel, FREQ_PANEL_POWER_PEAK_2, powerPeakStr1);
		 	SpectrumUnitConversion(autoSpectrumsff, numarpuncte/2,0, SCALING_MODE_LINEAR, DISPLAY_UNIT_VRMS, dff, winConst, convertedSpectrumsff, unit);
			DeleteGraphPlot (panel,FREQ_PANEL_GRAPH_SPECTRU_FILTRAT, -1, VAL_IMMEDIATE_DRAW);
			PlotWaveform(panel, FREQ_PANEL_GRAPH_SPECTRU_FILTRAT, convertedSpectrumsff, numarpuncte/4 , VAL_DOUBLE, 1.0, 0.0, 0.0, dff, VAL_THIN_LINE, VAL_EMPTY_SQUARE, VAL_SOLID, VAL_CONNECTED_POINTS, VAL_RED);
		
	}
	else
		if(tipAfisare==1)//tot semnalul
		{
			//spectru semnal filtrat si ferestruit
			double *convertedSpectrumsff=(double*)calloc(npoints/2,sizeof(double));
			double *autoSpectrumsff=(double*)calloc(npoints/2,sizeof(double));
			double dff=0.0;
			double powerPeak1=0.0;
			double freqPeak1=0.0;
			char unit[32]="";
			WindowConst winConst;
			
			ScaledWindowEx(semnalFF,npoints,RECTANGLE_,0,&winConst);
			AutoPowerSpectrum(semnalFF,npoints,1.0/sampleRate,autoSpectrumsff,&dff);
			//calculeaza puterea si frecventa corespunzatoare varfului din spectrul semnalului 
			PowerFrequencyEstimate(autoSpectrumsff, numarpuncte / 2, -1.0, winConst, dff, 7, &freqPeak1, &powerPeak1);
			char freqPeakStr1[50], powerPeakStr1[50];
			sprintf(freqPeakStr1, "%.2f", freqPeak1);
			sprintf(powerPeakStr1, "%.2f", powerPeak1);
			SetCtrlVal(panel, FREQ_PANEL_FREQUENCY_PEAK_2, freqPeakStr1);
			SetCtrlVal(panel, FREQ_PANEL_POWER_PEAK_2, powerPeakStr1);
			SpectrumUnitConversion(autoSpectrumsff, npoints/2,0, SCALING_MODE_LINEAR, DISPLAY_UNIT_VRMS, dff, winConst, convertedSpectrumsff, unit);
			DeleteGraphPlot (panel,FREQ_PANEL_GRAPH_SPECTRU_FILTRAT, -1, VAL_IMMEDIATE_DRAW);
			PlotWaveform(panel, FREQ_PANEL_GRAPH_SPECTRU_FILTRAT, convertedSpectrumsff, npoints/4 , VAL_DOUBLE, 1.0, 0.0, 0.0, dff, VAL_THIN_LINE, VAL_EMPTY_SQUARE, VAL_SOLID, VAL_CONNECTED_POINTS, VAL_RED);
	
		}
	else
		if(tipAfisare==2)//pe secunde
		{
			//spectru semnal filtrat si ferestruit
			double *convertedSpectrumsff=(double*)calloc(npoints/12,sizeof(double));
			double *autoSpectrumsff=(double*)calloc(npoints/12,sizeof(double));
			double dff=0.0;
			char unit[32]="V";
			WindowConst winConst;
			double powerPeak1=0.0;
			double freqPeak1=0.0;
			
			ScaledWindowEx(semnalFF,npoints/6,RECTANGLE_,0,&winConst);
			AutoPowerSpectrum(semnalFF,npoints/6,1.0/sampleRate,autoSpectrumsff,&dff);
			//calculeaza puterea si frecventa corespunzatoare varfului din spectrul semnalului 
			PowerFrequencyEstimate(autoSpectrumsff, numarpuncte / 2, -1.0, winConst, dff, 7, &freqPeak1, &powerPeak1);
			char freqPeakStr1[50], powerPeakStr1[50];
			sprintf(freqPeakStr1, "%.2f", freqPeak1);
			sprintf(powerPeakStr1, "%.2f", powerPeak1);
			SetCtrlVal(panel, FREQ_PANEL_FREQUENCY_PEAK_2, freqPeakStr1);
			SetCtrlVal(panel, FREQ_PANEL_POWER_PEAK_2, powerPeakStr1);
			SpectrumUnitConversion(autoSpectrumsff, npoints/12,0, SCALING_MODE_LINEAR, DISPLAY_UNIT_VRMS, dff, winConst, convertedSpectrumsff, unit);
			DeleteGraphPlot (panel,FREQ_PANEL_GRAPH_SPECTRU_FILTRAT, -1, VAL_IMMEDIATE_DRAW);
			PlotWaveform(panel, FREQ_PANEL_GRAPH_SPECTRU_FILTRAT, convertedSpectrumsff, npoints/24 , VAL_DOUBLE, 1.0, 0.0, 0.0, dff, VAL_THIN_LINE, VAL_EMPTY_SQUARE, VAL_SOLID, VAL_CONNECTED_POINTS, VAL_RED);
	
		}
	
}
void afispesecunde(int panel)
{
	double *convertedSpectrumsi= (double*)malloc((int)(npoints/12) * sizeof(double));
	double* autoSpectrumsi = (double*)malloc((int)(npoints/12) * sizeof(double));
	double powerPeak=0.0;
	double freqPeak=0.0;
	double df=0.0;
	char unit[32]="V";
	WindowConst winConst;
	GetCtrlAttribute(panel,FREQ_PANEL_SECOND,ATTR_CTRL_INDEX,&secunda);
	wavepersec=(double*)malloc((int)(npoints/6) * sizeof(double));
	for(int i=0;i<npoints/6;i++)
	{
		wavepersec[i]=waveData[npoints/6*secunda+i];
	}
	DeleteGraphPlot (panel,FREQ_PANEL_GRAPH, -1, VAL_IMMEDIATE_DRAW);
	PlotY(panel, FREQ_PANEL_GRAPH, wavepersec, npoints/6, VAL_DOUBLE, VAL_THIN_LINE, VAL_EMPTY_SQUARE, VAL_SOLID, VAL_CONNECTED_POINTS, VAL_RED);
			
	ScaledWindowEx(wavepersec,npoints/6,RECTANGLE_,0,&winConst);
	AutoPowerSpectrum(wavepersec,npoints/6,1.0/sampleRate,autoSpectrumsi,&df);
	//calculeaza puterea si frecventa corespunzatoare varfului din spectrul semnalului 
	PowerFrequencyEstimate(autoSpectrumsi,npoints/12,-1.0,winConst,df,7,&freqPeak,&powerPeak);
	char freqPeakStr[50]; 
	sprintf(freqPeakStr, "%.2f", freqPeak);

	SetCtrlVal(panel, FREQ_PANEL_FREQUENCY_PEAK_1, freqPeakStr); 
	char powerPeakStr[50];
	sprintf(powerPeakStr, "%.2f", powerPeak);

	SetCtrlVal(panel, FREQ_PANEL_POWER_PEAK_1, powerPeakStr);
	SpectrumUnitConversion(autoSpectrumsi, npoints/12,0, SCALING_MODE_LINEAR, DISPLAY_UNIT_VRMS, df, winConst, convertedSpectrumsi, unit);
	DeleteGraphPlot (panel,FREQ_PANEL_GRAPH_SPECTRU, -1, VAL_IMMEDIATE_DRAW);
	PlotWaveform(panel, FREQ_PANEL_GRAPH_SPECTRU, convertedSpectrumsi, npoints/24 , VAL_DOUBLE, 1.0, 0.0, 0.0, df, VAL_THIN_LINE, VAL_EMPTY_SQUARE, VAL_SOLID, VAL_CONNECTED_POINTS, VAL_RED);
			
	aplicareFiltru(panel);
	aplicareFereastra(panel);
	afisareSpectru(panel);
			
}
void afisSemnalIntreg(int panel)
{
	double *convertedSpectrumsi= (double*)malloc((int)(npoints/2) * sizeof(double));
	double* autoSpectrumsi = (double*)malloc((int)(npoints/2) * sizeof(double));
	double powerPeak=0.0;
	double freqPeak=0.0;
	double df=0.0;
	char unit[32]="V";
	WindowConst winConst;
	
		
	DeleteGraphPlot (panel,FREQ_PANEL_GRAPH, -1, VAL_IMMEDIATE_DRAW);
	PlotY(panel, FREQ_PANEL_GRAPH, waveData, npoints, VAL_DOUBLE, VAL_THIN_LINE, VAL_EMPTY_SQUARE, VAL_SOLID, VAL_CONNECTED_POINTS, VAL_RED);
			
	ScaledWindowEx(waveData,npoints,RECTANGLE_,0,&winConst);
	AutoPowerSpectrum(waveData,npoints,1.0/sampleRate,autoSpectrumsi,&df);
	//calculeaza puterea si frecventa corespunzatoare varfului din spectrul semnalului 
	PowerFrequencyEstimate(autoSpectrumsi,npoints/2,-1.0,winConst,df,7,&freqPeak,&powerPeak);
	char freqPeakStr[50]; 
	sprintf(freqPeakStr, "%.2f", freqPeak);

	SetCtrlVal(panel, FREQ_PANEL_FREQUENCY_PEAK_1, freqPeakStr);

	char powerPeakStr[50];
	sprintf(powerPeakStr, "%.2f", powerPeak);

	SetCtrlVal(panel, FREQ_PANEL_POWER_PEAK_1, powerPeakStr);
	SpectrumUnitConversion(autoSpectrumsi, npoints/2,0, SCALING_MODE_LINEAR, DISPLAY_UNIT_VRMS, df, winConst, convertedSpectrumsi, unit);
	DeleteGraphPlot (panel,FREQ_PANEL_GRAPH_SPECTRU, -1, VAL_IMMEDIATE_DRAW);
	PlotWaveform(panel, FREQ_PANEL_GRAPH_SPECTRU, convertedSpectrumsi, npoints/4 , VAL_DOUBLE, 1.0, 0.0, 0.0, df, VAL_THIN_LINE, VAL_EMPTY_SQUARE, VAL_SOLID, VAL_CONNECTED_POINTS, VAL_RED);
			
	aplicareFiltru(panel);
	aplicareFereastra(panel);
	afisareSpectru(panel);
}
 CVICALLBACK OnTimer (int panel, int control, int event,
						 void *callbackData, int eventData1, int eventData2)
{
	
	double* convertedSpectrumsi = (double*)malloc((int)(npoints) * sizeof(double));
	double* autoSpectrumsi = (double*)malloc((int)(npoints) * sizeof(double));
	double powerPeak=0.0;
	double freqPeak=0.0;
	double df=0.0;
	char unit[32]="";
	
	WindowConst winConst;
	switch (event)
	{
		case EVENT_TIMER_TICK:
			GetCtrlVal(panel, FREQ_PANEL_BUFFER_SIZE, &numarpuncte);
			double *wave=(double*)calloc(numarpuncte,sizeof(double));
			

			for(int i=0;i<numarpuncte;i++)
			{
				wave[i]=waveData[i+numarpuncte*nrFereastra];
			}
			DeleteGraphPlot (panel,FREQ_PANEL_GRAPH, -1, VAL_IMMEDIATE_DRAW);
			PlotY(panel, FREQ_PANEL_GRAPH, wave, numarpuncte, VAL_DOUBLE, VAL_THIN_LINE, VAL_EMPTY_SQUARE, VAL_SOLID, VAL_CONNECTED_POINTS, VAL_RED);
			//spectru semnal initial
			
			numarFerestre = (int)(((double)npoints) / numarpuncte);
			if (((double)npoints) / numarpuncte - numarFerestre > 0.0)
			{
				numarFerestre++;
			}
			waveDataPerNrPuncte=(double*)calloc(numarpuncte*numarFerestre,sizeof(double));
			
			for(int i=0;i<numarpuncte*numarFerestre;i++)//formam wave data
			{
				if(i<npoints)
				{
					waveDataPerNrPuncte[i]=waveData[i];
				}
				else
				{
					waveDataPerNrPuncte[i]=0;
				}
			}
			
			
			convertedSpectrumsi=(double*)calloc(numarpuncte/2,sizeof(double));
			autoSpectrumsi=(double*)calloc(numarpuncte/2,sizeof(double));
			
			ScaledWindowEx(waveDataPerNrPuncte+nrFereastra*numarpuncte,numarpuncte,RECTANGLE_,0,&winConst);
			AutoPowerSpectrum(waveDataPerNrPuncte+nrFereastra*numarpuncte,numarpuncte,1.0/sampleRate,autoSpectrumsi,&df);
			//calculeaza puterea si frecventa corespunzatoare varfului din spectrul semnalului 
			PowerFrequencyEstimate(autoSpectrumsi,numarpuncte/2,-1.0,winConst,df,7,&freqPeak,&powerPeak);
			char freqPeakStr[50];
			sprintf(freqPeakStr, "%.2f", freqPeak);

			SetCtrlVal(panel, FREQ_PANEL_FREQUENCY_PEAK_1, freqPeakStr);

			char powerPeakStr[50];
			sprintf(powerPeakStr, "%.2f", powerPeak);

			SetCtrlVal(panel, FREQ_PANEL_POWER_PEAK_1, powerPeakStr);
		 	SpectrumUnitConversion(autoSpectrumsi, numarpuncte/2,0, SCALING_MODE_LINEAR, DISPLAY_UNIT_VRMS, df, winConst, convertedSpectrumsi, unit);
			DeleteGraphPlot (panel,FREQ_PANEL_GRAPH_SPECTRU, -1, VAL_IMMEDIATE_DRAW);
			PlotWaveform(panel, FREQ_PANEL_GRAPH_SPECTRU, convertedSpectrumsi, numarpuncte/4 , VAL_DOUBLE, 1.0, 0.0, 0.0, df, VAL_THIN_LINE, VAL_EMPTY_SQUARE, VAL_SOLID, VAL_CONNECTED_POINTS, VAL_RED);
			
			aplicareFiltru(panel);
			aplicareFereastra(panel);
			
			
			
			
			if(nrFereastra==numarFerestre)
			{
				nrFereastra=0;
			}
			else
				nrFereastra++;
			break;
	}
	return 0;
}
int CVICALLBACK OnSave2 (int panel, int control, int event,
                         void *callbackData, int eventData1, int eventData2)
{
    switch (event)
    {
        case EVENT_COMMIT:
            int bitmapID = 0;
            char* filename = 0;
            filename = (char*)calloc(100, sizeof(char));

            // Spectru semnal initial
            GetCtrlDisplayBitmap(panel, FREQ_PANEL_GRAPH_SPECTRU, 1, &bitmapID);
            if (tipAfisare == 0)
            {
                sprintf(filename, "Spectru_initial_%d_%d.png", nrFereastra * numarpuncte, (nrFereastra + 1) * numarpuncte - 1);
            }
            else if (tipAfisare == 1)
            {
                sprintf(filename, "Spectru_initial_intreg.png");
            }
            else if (tipAfisare == 2)
            {
                sprintf(filename, "Spectru_initial_secunda_%d_%d.png", secunda, secunda + 1);
            }
            SaveBitmapToJPEGFile(bitmapID, filename, JPEG_DCTFLOAT, 50);
            DiscardBitmap(bitmapID);

            
            GetCtrlDisplayBitmap(panel, FREQ_PANEL_GRAPH_FEREASTRA, 1, &bitmapID);
            if (tipAfisare == 0)
            {
                if (tipFereastra == 0)
                {
                    sprintf(filename, "Fereastra_Hamming_%d_%d.png", nrFereastra * numarpuncte, (nrFereastra + 1) * numarpuncte - 1);
                }
                else if (tipFereastra == 1)
                {
                    sprintf(filename, "Fereastra_Hanning_%d_%d.png", nrFereastra * numarpuncte, (nrFereastra + 1) * numarpuncte - 1);
                }
            }
            else if (tipAfisare == 1)
            {
                if (tipFereastra == 0)
                {
                    sprintf(filename, "Fereastra_Hamming_intreg.png");
                }
                else if (tipFereastra == 1)
                {
                    sprintf(filename, "Fereastra_Hanning_intreg.png");
                }
            }
            else if (tipAfisare == 2)
            {
                if (tipFereastra == 0)
                {
                    sprintf(filename, "Fereastra_Hamming_secunda_%d_%d.png", secunda, secunda + 1);
                }
                else if (tipFereastra == 1)
                {
                    sprintf(filename, "Fereastra_Hanning_secunda_%d_%d.png", secunda, secunda + 1);
                }
            }

            SaveBitmapToJPEGFile(bitmapID, filename, JPEG_DCTFLOAT, 50);
            DiscardBitmap(bitmapID);

            // Semnal filtrat
            GetCtrlDisplayBitmap(panel, FREQ_PANEL_GRAPH_SF, 1, &bitmapID);
            if (tipAfisare == 0)
            {
                if (tipFiltru == 0)
                {
                    sprintf(filename, "Filtru_Butterworth_trece_jos_numarpuncte_%d_%d.png", nrFereastra * numarpuncte, (nrFereastra + 1) * numarpuncte - 1);
                }
                else if (tipFiltru == 1)
                {
                    sprintf(filename, "Filtru_Chebyshev_trece_jos_%d_%d.png", nrFereastra * numarpuncte, (nrFereastra + 1) * numarpuncte - 1);
                }
            }
            else if (tipAfisare == 1)
            {
                if (tipFiltru == 0)
                {
                    sprintf(filename, "Filtru_Butterworth_trece_jos_intreg.png");
                }
                else if (tipFiltru == 1)
                {
                    sprintf(filename, "Filtru_Chebyshev_trece_jos_intreg.png");
                }
            }
            else if (tipAfisare == 2)
            {
                if (tipFiltru == 0)
                {
                    sprintf(filename, "Filtru_Butterworth_trece_jos_secunda_%d_%d.png", secunda, secunda + 1);
                }
                else if (tipFiltru == 1)
                {
                    sprintf(filename, "Filtru_Chebyshev_trece_jos_secunda_%d_%d.png", secunda, secunda + 1);
                }
            }

            SaveBitmapToJPEGFile(bitmapID, filename, JPEG_DCTFLOAT, 50);
            DiscardBitmap(bitmapID);

            // Semnal filtrat si ferestruit
            GetCtrlDisplayBitmap(panel, FREQ_PANEL_GRAPH_FILTRAT, 1, &bitmapID);
            if (tipAfisare == 0)
            {
                if (tipFereastra == 1)
                {
                    if (tipFiltru == 0)
                    {
                        sprintf(filename, "Fereastra_Hamming_filtru_Butterworth_%d_%d.png", nrFereastra * numarpuncte, (nrFereastra + 1) * numarpuncte - 1);
                    }
                    else if (tipFiltru == 1)
                    {
                        sprintf(filename, "Fereastra_Hamming_filtru_Chebyshev_%d_%d.png", nrFereastra * numarpuncte, (nrFereastra + 1) * numarpuncte - 1);
                    }
                }
                else if (tipFereastra == 2)
                {
                    if (tipFiltru == 0)
                    {
                        sprintf(filename, "Fereastra_Hanning_filtru_Butterworth_%d_%d.png", nrFereastra * numarpuncte, (nrFereastra + 1) * numarpuncte - 1);
                    }
                    else if (tipFiltru == 1)
                    {
                        sprintf(filename, "Fereastra_Hanning_filtru_Chebyshev_%d_%d.png", nrFereastra * numarpuncte, (nrFereastra + 1) * numarpuncte - 1);
                    }
                }
            }
            else if (tipAfisare == 1)
            {
                if (tipFereastra == 0)
                {
                    if (tipFiltru == 0)
                    {
                        sprintf(filename, "Fereastra_Hamming_filtru_Butterworth_intreg.png");
                    }
                    else if (tipFiltru == 1)
                    {
                        sprintf(filename, "Fereastra_Hamming_filtru_Chebyshev_intreg.png");
                    }
                }
                else if (tipFereastra == 1)
                {
                    if (tipFiltru == 0)
                    {
                        sprintf(filename, "Fereastra_Hanning_filtru_Butterworth_intreg.png");
                    }
                    else if (tipFiltru == 1)
                    {
                        sprintf(filename, "Fereastra_Hanning_filtru_Chebyshev_intreg.png");
                    }
                }
            }
            else if (tipAfisare == 2)
            {
                if (tipFereastra == 0)
                {
                    if (tipFiltru == 0)
                    {
                        sprintf(filename, "Fereastra_Hamming_filtru_Butterworth_secunda_%d_%d.png", secunda, secunda + 1);
                    }
                    else if (tipFiltru == 1)
                    {
                        sprintf(filename, "Fereastra_Hamming_filtru_Chebyshev_secunda_%d_%d.png", secunda, secunda + 1);
                    }
                }
                else if (tipFereastra == 2)
                {
                    if (tipFiltru == 0)
                    {
                        sprintf(filename, "Fereastra_Hanning_filtru_Butterworth_secunda_%d_%d.png", secunda, secunda + 1);
                    }
                    else if (tipFiltru == 1)
                    {
                        sprintf(filename, "Fereastra_Hanning_filtru_Chebyshev_secunda_%d_%d.png", secunda, secunda + 1);
                    }
                }
            }

            SaveBitmapToJPEGFile(bitmapID, filename, JPEG_DCTFLOAT, 50);
            DiscardBitmap(bitmapID);
            free(filename);
            break;
    }
    return 0;
}
