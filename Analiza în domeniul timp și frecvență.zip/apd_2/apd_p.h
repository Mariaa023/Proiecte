/**************************************************************************/
/* LabWindows/CVI User Interface Resource (UIR) Include File              */
/*                                                                        */
/* WARNING: Do not add to, delete from, or otherwise modify the contents  */
/*          of this include file.                                         */
/**************************************************************************/

#include <userint.h>

#ifdef __cplusplus
    extern "C" {
#endif

     /* Panels and Controls: */

#define  FREQ_PANEL                       1       /* callback function: OnFrequencyPanel */
#define  FREQ_PANEL_SWITCH_PANEL          2       /* control type: binary, callback function: OnSwitchPanelCB */
#define  FREQ_PANEL_GRAPH                 3       /* control type: graph, callback function: (none) */
#define  FREQ_PANEL_BUFFER_SIZE           4       /* control type: numeric, callback function: (none) */
#define  FREQ_PANEL_WINDOW_TYPE           5       /* control type: ring, callback function: WindowType */
#define  FREQ_PANEL_FILTER_TYPE           6       /* control type: ring, callback function: OnFilterType */
#define  FREQ_PANEL_GRAPH_FEREASTRA       7       /* control type: graph, callback function: (none) */
#define  FREQ_PANEL_SECOND                8       /* control type: ring, callback function: SecondFrequency */
#define  FREQ_PANEL_GRAPH_FILTRAT         9       /* control type: graph, callback function: (none) */
#define  FREQ_PANEL_GRAPH_SPECTRU         10      /* control type: graph, callback function: (none) */
#define  FREQ_PANEL_GRAPH_SF              11      /* control type: graph, callback function: (none) */
#define  FREQ_PANEL_GRAPH_SPECTRU_FILTRAT 12      /* control type: graph, callback function: (none) */
#define  FREQ_PANEL_TIP_AFISARE           13      /* control type: ring, callback function: OnShow */
#define  FREQ_PANEL_TIMER                 14      /* control type: timer, callback function: OnTimer */
#define  FREQ_PANEL_FREQUENCY_PEAK_1      15      /* control type: string, callback function: (none) */
#define  FREQ_PANEL_POWER_PEAK_1          16      /* control type: string, callback function: (none) */
#define  FREQ_PANEL_SAVE2                 17      /* control type: command, callback function: OnSave2 */
#define  FREQ_PANEL_FREQUENCY_PEAK_2      18      /* control type: string, callback function: (none) */
#define  FREQ_PANEL_POWER_PEAK_2          19      /* control type: string, callback function: (none) */

#define  PANEL                            2
#define  PANEL_GRAPH                      2       /* control type: graph, callback function: (none) */
#define  PANEL_Load_button                3       /* control type: command, callback function: LoadButton */
#define  PANEL_MIN                        4       /* control type: string, callback function: (none) */
#define  PANEL_MAX                        5       /* control type: string, callback function: (none) */
#define  PANEL_IndexMin                   6       /* control type: string, callback function: (none) */
#define  PANEL_IndexMax                   7       /* control type: string, callback function: (none) */
#define  PANEL_MEDIE                      8       /* control type: string, callback function: (none) */
#define  PANEL_DISPERSIE                  9       /* control type: string, callback function: (none) */
#define  PANEL_MEDIANA                    10      /* control type: string, callback function: (none) */
#define  PANEL_TRECERI_ZERO               11      /* control type: string, callback function: (none) */
#define  PANEL_HISTOGRAMA                 12      /* control type: graph, callback function: (none) */
#define  PANEL_alpha                      13      /* control type: numeric, callback function: (none) */
#define  PANEL_window_size                14      /* control type: numeric, callback function: (none) */
#define  PANEL_RING                       15      /* control type: ring, callback function: (none) */
#define  PANEL_ApplyFILTER                16      /* control type: command, callback function: ApplyFilter */
#define  PANEL_FILTRU                     17      /* control type: graph, callback function: (none) */
#define  PANEL_SKEWNESS1                  18      /* control type: string, callback function: (none) */
#define  PANEL_KURTOSIS1                  19      /* control type: string, callback function: (none) */
#define  PANEL_PREVBUTTON                 20      /* control type: command, callback function: PrevButton */
#define  PANEL_NEXTBUTTON                 21      /* control type: command, callback function: NextButton */
#define  PANEL_RING_2                     22      /* control type: ring, callback function: (none) */
#define  PANEL_SWITCH_PANEL               23      /* control type: binary, callback function: OnSwitchPanelCB */


     /* Control Arrays: */

          /* (no control arrays in the resource file) */


     /* Menu Bars, Menus, and Menu Items: */

          /* (no menu bars in the resource file) */


     /* Callback Prototypes: */

int  CVICALLBACK ApplyFilter(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK LoadButton(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK NextButton(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK OnFilterType(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK OnFrequencyPanel(int panel, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK OnSave2(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK OnShow(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK OnSwitchPanelCB(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK OnTimer(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK PrevButton(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK SecondFrequency(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK WindowType(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);


#ifdef __cplusplus
    }
#endif
