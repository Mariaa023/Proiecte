package Collision;

import Camera.Camera;
import Tiles.ConcreteTile;
import Tiles.TileFactory;
import main.FirstLevel;
import main.Game;
import Tiles.Tile;
import main.Player;

import java.awt.*;
import java.awt.geom.Rectangle2D;

public class HelpMethods {
    public static boolean CanMoveHere(float x, float y, float width, float height, int[][][] lvl,int map) {
//verific daca e coliziune cu vreun element de pe harta
       if(!IsSolid(x,y,lvl,map))
           if(!IsSolid(x+width,y+height,lvl,map))
                if(!IsSolid(x+width,y,lvl,map))
                    if(!IsSolid(x,y+height,lvl,map))
                        return true;
        return false;
    }


    private static boolean IsSolid(float x, float y, int[][][] levelData,int map) {
       //verific daca e coliziune cu vreun element de pe harta
        int maxWidth = levelData[map][0].length *ConcreteTile.Tile_width;

        if (x < 0 || x >= maxWidth)
            return true;

        if (y < 0 || y >= 768)
            return true;

        int xIndex = (int)x / ConcreteTile.Tile_height;
        int yIndex = (int)y / ConcreteTile.Tile_width;
        if(FirstLevel.currentMap==0)
        yIndex++;

       int value = levelData[map][yIndex][xIndex];

        if (value >=14 || value < 0)
           return true;
        else if (TileFactory.getTile(value) != null) {
           return TileFactory.getTile(value).IsSolid();
        } else
            return false;


    }
    public static float GetEntityXPosNextToWall(Rectangle2D.Float hitbox)
    {
        //punem caracterul langa perete
        return hitbox.x;
    }
    public static float GetEntityYPosUnderRoofFloor(Rectangle2D.Float hitbox)
    {
        //punem caracterul sub tavan
        return hitbox.y;
    }

   public static boolean IsEntityOnFloor(Rectangle2D.Float hitBox, int[][][] levelData,int map,Player p)
    {
        //verificam daca e pe ceva solid
      // adica sa cada cand nu are nimic sub

       if(!IsSolid((int)(hitBox.x),(int)(hitBox.y+hitBox.height),levelData,map))
            if(!IsSolid((int)(hitBox.x + hitBox.width), (int)(hitBox.y + hitBox.height), levelData,map)) // adaugam +1 ca l-am scazut in celelalte metode
                return false;

       return true;
   }
}
