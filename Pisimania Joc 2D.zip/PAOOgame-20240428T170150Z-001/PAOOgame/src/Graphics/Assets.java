package Graphics;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;

/*! \class public class Assets
    \brief Clasa incarca fiecare element grafic necesar jocului.

    Game assets include tot ce este folosit intr-un joc: imagini, sunete, harti etc.
 */
public class Assets
{
    /// Referinte catre elementele grafice (dale) utilizate in joc.
    ///Floor
    public static BufferedImage grass;
    public static BufferedImage tree;
    //referinte catre busola
    public static BufferedImage compass;
    //referinta catre Pisidina, zana ajutatoare
    public static BufferedImage pisidina;
    //referinta catre personajul principal
    public static BufferedImage [][]pisyna;
    //referinta catre tile urile folosite
    public static BufferedImage floor;
    public static BufferedImage cloud1;
    public static BufferedImage cloud2;
    public static BufferedImage sky;
    public static BufferedImage soil;
    public static BufferedImage stone;
    public static BufferedImage poison;
    public static BufferedImage background;
    public static BufferedImage background1;
    public static BufferedImage house;
    public static BufferedImage house1;

    /*! \fn public static void Init()
        \brief Functia initializaza referintele catre elementele grafice utilizate.

        Aceasta functie poate fi rescrisa astfel incat elementele grafice incarcate/utilizate
        sa fie parametrizate. Din acest motiv referintele nu sunt finale.
     */
    public static void Init()
    {
        /// Se creaza temporar un obiect SpriteSheet initializat prin intermediul clasei ImageLoader

        SpriteSheet sheetfloor=new SpriteSheet(ImageLoader.LoadImage("/textures/floor.png"));
        SpriteSheet sheetPisyna = new SpriteSheet(ImageLoader.LoadImage("/textures/pisica.png"));
        //incarc busola de la nivelul 1
        compass=ImageLoader.LoadImage("/textures/busola.png");
        //incarc personajul ajutator
        pisidina=ImageLoader.LoadImage("/textures/pisidina.png");

       //decupez si folosesc imaginile de care am nevoie pentru tile uri
        grass=sheetfloor.crop(0,0);
        tree=sheetfloor.crop(3,1);
        floor=ImageLoader.LoadImage("/textures/iarba.png");
        cloud1=ImageLoader.LoadImage("/textures/cloud1.png");
        cloud2=ImageLoader.LoadImage("/textures/cloud2.png");
        sky=ImageLoader.LoadImage("/textures/sky.png");
        soil=ImageLoader.LoadImage("/textures/pamant.png");
        stone=ImageLoader.LoadImage("/textures/stone.jpg");
        poison=ImageLoader.LoadImage("/textures/poison.jpg");
        background=ImageLoader.LoadImage("/textures/background.jpg");
        background1=ImageLoader.LoadImage("/textures/background1.png");
        house=ImageLoader.LoadImage("/textures/house.jpg");
        house1=ImageLoader.LoadImage("/textures/house1.png");
        //incarc imaginile cu pisina

        pisyna=new BufferedImage[8][12];
        for(int i=0;i<8;i++)
            for(int j=0;j<12;j++)
            {
                pisyna[i][j]=sheetPisyna.cropPisyna(j,i);
            }

    }
}
