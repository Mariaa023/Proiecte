package Graphics;
import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
public class SpriteSheet {
    private BufferedImage spriteSheet;
    //declar dimensiunile necesare pentru tile uri
    private static final int tileWidth=48;
    private static final int tileHeight=48;
    private static final int pisynaWidth=32;
    private static final int pisynaHeight=32;
    public SpriteSheet(BufferedImage b)
    {
        spriteSheet=b;
    }
    //decupez ce imagine imi trebuie ca sa construiesc harta
    public BufferedImage crop(int x,int y)
    {
        return spriteSheet.getSubimage(x*tileWidth,y*tileHeight,tileWidth,tileHeight);
    }
    //decupez ce imagine imi trebuie ca sa construiesc personajul
    public BufferedImage cropPisyna(int x,int y)
    {
        return spriteSheet.getSubimage(x*pisynaWidth,y*pisynaHeight,pisynaWidth,pisynaHeight);
    }

}
