package Heart;
import Graphics.ImageLoader;
import java.awt.*;

public class Obj_Heart extends SuperObject{
    public Obj_Heart(Graphics g)
    {
        //incarc imaginile pentru a desena vietile jucatorului
        name="Heart";
        image2= ImageLoader.LoadImage("/textures/heart_empty.png");
        image1=ImageLoader.LoadImage("/textures/heart_full.png");
    }
}
