package Heart;

import main.Game;

import java.awt.*;
import java.awt.image.BufferedImage;

public class SuperObject {
    //clasa care se ocupa cu instantierea obiectului inima (viata jucatorului)
    public BufferedImage image1, image2;
    public String name;
    public Rectangle solidArea =new Rectangle(0,0,48,48);
}
