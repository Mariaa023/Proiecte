package Camera;
import GameWindow.GameWindow;
import main.FirstLevel;
import main.Player;

public class Camera {
    public static int xCamera;//variabila care muta harta mai in stanga sau mai in dreapta
    public static boolean moveRight=false;//variabila care se modifica cand caracterul se misca in dreapta
    public static boolean moveLeft=false;//variabila care se modifica cand caracterul se misca in stanga

    public static void update(Player p)
    {
        if(FirstLevel.currentMap==1) {//miscarea camerei pentru nivelul 2
            if (moveRight)
                xCamera = xCamera + 2;
            if (moveLeft)
                xCamera = xCamera - 1;
            int speed = 2; // Viteza cu care se mișcă camera
            if (moveRight && xCamera < (p.maxlvlOffsetX - GameWindow.GetWndWidth())) {
                xCamera += speed;
            }
            if (moveLeft && xCamera > 0) {
                xCamera -= speed;
            }
        }
        else if(FirstLevel.currentMap==2) {//miscarea camerei pentru nivelul 3
            if (moveRight)
                xCamera = xCamera + 1;
            if (moveLeft)
                xCamera = xCamera - 1;
        }

    }
}
