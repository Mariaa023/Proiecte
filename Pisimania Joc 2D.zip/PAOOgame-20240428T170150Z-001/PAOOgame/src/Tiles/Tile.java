package Tiles;

import java.awt.*;
import java.awt.image.BufferedImage;
//interfata defineste metodele de baza pentru tile uri
public interface Tile {
    void Draw(Graphics g, int x, int y);
    boolean IsSolid();
}
