package Tiles;

import Graphics.Assets;

import java.awt.image.BufferedImage;
import java.util.HashMap;
import java.util.Map;
//crearea si gestionarea tile urilor
public class TileFactory {
    private static final int no_tiles = 32;//nr de tipuri de dale
    private static final Map<Integer, Tile> tileMap = new HashMap<>();//mapa care stocheaza dalele
    // Blocul static pentru initializarea dalelor si adaugarea lor in mapa
    static {
        tileMap.put(0, new ConcreteTile(Assets.grass, 0, false));
        tileMap.put(1, new ConcreteTile(Assets.tree, 1, true));
        tileMap.put(2, new ConcreteTile(Assets.pisyna[6][0], 2, false));
        tileMap.put(3, new ConcreteTile(Assets.compass, 3, false));
        tileMap.put(4, new ConcreteTile(Assets.floor, 4, true));
        tileMap.put(5, new ConcreteTile(Assets.cloud1, 5, true));
        tileMap.put(6, new ConcreteTile(Assets.cloud2, 6, true));
        tileMap.put(7, new ConcreteTile(Assets.sky, 7, false));
        tileMap.put(8, new ConcreteTile(Assets.soil, 8, true));
        tileMap.put(9, new ConcreteTile(Assets.stone, 9, true));
        tileMap.put(10, new ConcreteTile(Assets.poison, 10, true));
        tileMap.put(11, new ConcreteTile(null, 11, false));
        tileMap.put(12, new ConcreteTile(Assets.house, 12, false));
        tileMap.put(13, new ConcreteTile(Assets.house1, 13, true));
    }

    public static Tile getTile(int id) {
        return tileMap.get(id);
    }
}
