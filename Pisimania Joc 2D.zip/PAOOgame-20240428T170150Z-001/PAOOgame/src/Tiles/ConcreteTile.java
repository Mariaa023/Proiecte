package Tiles;

import java.awt.*;
import java.awt.image.BufferedImage;
//clasa care implementeaza interfata Tile si face Tile-urile necesare
public class ConcreteTile implements Tile {
    private BufferedImage img;//imaginea dalei
    private final int id;//id-ul dalei
    private boolean coli;//daca exista coliziune
    public static final int Tile_width = 48;//lungimea dalei
    public static final int Tile_height = 48;//latimea dalei

    public ConcreteTile(BufferedImage image, int idd, boolean coli) {
        //constructorul
        img = image;
        id = idd;
        this.coli = coli;
    }

    @Override
    public void Draw(Graphics g, int x, int y) {
        //desenam dalele
        g.drawImage(img, x, y, Tile_width, Tile_height, null);
    }

    @Override
    public boolean IsSolid() {
        //vedem daca are coliziune
        return coli;
    }

}
