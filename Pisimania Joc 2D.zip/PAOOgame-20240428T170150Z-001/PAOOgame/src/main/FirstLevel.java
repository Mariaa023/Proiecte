package main;

import Camera.Camera;
import Tiles.ConcreteTile;
import Tiles.Tile;
import Tiles.TileFactory;

import java.awt.*;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Random;
import Graphics.Assets;

public class FirstLevel {
    private static Graphics g;//variabila care ma ajuta sa desenez pe ecran
    public static int[][][] table0;//harta de la primul nivel
    public static int[][][] table1;//harta de la al doilea nivel
    public static int[][][] table2;//harta de la al treilea nivel
    public static int[][] compassTable;//harta aferenta pentru plasarea busolei
    private int[][] compassCoords;//ajuta la desenarea busolei
    private int gameWidth;//lungimea ferestrei
    private int gameHeight;//latimea ferestrei
    private int widthInTiles;//lungimea hartii la primul nivel
    private int heightInTiles;//latimea hartii la primul nivel
    public static int score;//daca colecteaza busola
    public static final int maxMap = 3;//cate harti sunt in total
    public static int currentMap = 0;//harta curenta
    public static final int maxWorldCol = 32;//lungimea hartii la nivelele 2 si 3
    public static final int maxWorldRow = 32;//latimea hartii la nivelele 2 si 3

    public FirstLevel(int gameWidth, int gameHeight) {
        //constructorul clasei
        //initializam valorile pentru fereastra jocului
        this.gameWidth = gameWidth;
        this.gameHeight = gameHeight;
        this.widthInTiles = gameWidth / ConcreteTile.Tile_width;
        this.heightInTiles = gameHeight / ConcreteTile.Tile_height;
        //initializam scorul
        score = 0;
        //initializam hartile
        table0 = new int[maxMap][heightInTiles + 1][widthInTiles + 1];
        table1 = new int[maxMap][maxWorldCol + 1][maxWorldRow + 1];
        table2 = new int[maxMap][maxWorldCol + 1][maxWorldRow + 1];
        //initializam harta pentru busola
        compassTable = new int[heightInTiles + 2][widthInTiles + 2];
        compassCoords = new int[heightInTiles + 1][widthInTiles + 1];
        //desenezi busola
        DrawCompass();
    }

    public void loadMap2(String file, int map) {
        //incarcam harta la nivelul 3
        try {
            InputStream is = getClass().getResourceAsStream(file);
            BufferedReader br = new BufferedReader(new InputStreamReader(is));
            int col = 0;
            int row = 0;
            while (col < maxWorldCol && row < maxWorldRow) {
                //citim cate o linie din harta
                String line = br.readLine();
                if (line == null) {
                    break; // Sfârșitul fișierului
                }
                while (col < maxWorldCol) {
                    //citim din harta id-ul tale-ului si incarcam poza aferenta
                    String[] numbers = line.split(" ");
                    int num = Integer.parseInt(numbers[col]);
                    table2[map][row][col] = num;
                    col++;
                }
                if (col == maxWorldCol) {
                    col = 0;
                    row++;
                }
            }
            br.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void loadMap1(String file, int map) {
        //incarcam harta la nivelul 2
        try {
            InputStream is = getClass().getResourceAsStream(file);
            BufferedReader br = new BufferedReader(new InputStreamReader(is));
            int col = 0;
            int row = 0;
            while (col < maxWorldCol && row < maxWorldRow) {
                //citim cate o linie din harta
                String line = br.readLine();
                if (line == null) {
                    break; // Sfârșitul fișierului
                }
                while (col < maxWorldCol) {
                    //citim din harta id-ul tale-ului si incarcam poza aferenta
                    String[] numbers = line.split(" ");
                    int num = Integer.parseInt(numbers[col]);
                    table1[map][row][col] = num;
                    col++;
                }
                if (col == maxWorldCol) {
                    col = 0;
                    row++;
                }
            }
            br.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void loadMap0(String file, int map) {
        //incarcam harta la nivelul 1
        try {
            InputStream is = getClass().getResourceAsStream(file);
            BufferedReader br = new BufferedReader(new InputStreamReader(is));
            int col = 0;
            int row = 0;

            while (col < widthInTiles && row < heightInTiles) {
                //citim cate o linie din harta
                String line = br.readLine();
                if (line == null) {
                    break; // Sfârșitul fișierului
                }
                while (col < widthInTiles) {
                    //citim din harta id-ul tale-ului si incarcam poza aferenta
                    String[] numbers = line.split(" ");
                    int num = Integer.parseInt(numbers[col]);
                    table0[map][row][col] = num;
                    col++;
                }
                if (col == widthInTiles) {
                    col = 0;
                    row++;
                }
            }
            br.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void DrawMap(Graphics g) {
        //desenam hartile
        this.g = g;
        //harta la primul nivel
        if (currentMap == 0) {
            for (int i = 0; i < heightInTiles; ++i)
                for (int j = 0; j < widthInTiles; ++j) {
                    TileFactory.getTile(table0[currentMap][i][j]).Draw(g, j * ConcreteTile.Tile_width, i * ConcreteTile.Tile_height);
                }
            //harta la al doilea
        } else if (currentMap == 1) {
            g.drawImage(Assets.background1, 0, 0, null);
            for (int i = 0; i < maxWorldCol; ++i)
                for (int j = 0; j < maxWorldRow; ++j) {
                    TileFactory.getTile(table1[currentMap][i][j]).Draw(g, j * ConcreteTile.Tile_width - Camera.xCamera, i * ConcreteTile.Tile_height);
                }
            //harta la al treilea
        } else if (currentMap == 2) {
            g.drawImage(Assets.background, 0, 0, null);
            for (int i = 0; i < maxWorldCol; ++i)
                for (int j = 0; j < maxWorldRow; ++j) {
                    TileFactory.getTile(table2[currentMap][i][j]).Draw(g, j * ConcreteTile.Tile_width - Camera.xCamera, i * ConcreteTile.Tile_height);
                }
        }
        //desenam harta si scorul busolei la primul nivel

        if (FirstLevel.currentMap == 0) {
            Font fnt0 = new Font("Monospaced", Font.BOLD, 14);
            g.setFont(fnt0);
            g.setColor(Color.white);
            g.drawString("Busola: " + score, 650, 15);
            for (int i = 0; i < heightInTiles; ++i)
                for (int j = 0; j < widthInTiles; ++j)
                    if (compassTable[i][j] != 0)
                        TileFactory.getTile(compassTable[i][j]).Draw(g, j * ConcreteTile.Tile_width, i * ConcreteTile.Tile_height);
        }
    }

    public void DrawCompass() {
        //densenam busola la primul nivel
        if (FirstLevel.currentMap == 0)
            compassTable[9][6] = 3;
    }

    public void SelectCompass(int x, int y) {
        //verificam daca e busola ca sa o colecteze
        if (FirstLevel.currentMap == 0) {
            int pozX, pozY;
            pozX = x / ConcreteTile.Tile_width;
            pozY = y / ConcreteTile.Tile_height;

            if (compassTable[pozY][pozX] != 0) {
                compassTable[pozY][pozX] = 0;
                score++;
                DrawMap(g);
            }
        }
    }

    public static boolean isCompass(int aux1, int aux2) {
        //vedem daca e busola pe acea pozitie
        if (FirstLevel.currentMap == 0) {
            int pozX, pozY;
            pozX = aux1 /ConcreteTile.Tile_width;
            pozY = aux2 / ConcreteTile.Tile_height;
            return compassTable[pozY][pozX] == 3;
        }
        return false;
    }

    public static int getScore() {
        return score;
    }

    public static void setScore(int s) {
        score = s;
    }
}
