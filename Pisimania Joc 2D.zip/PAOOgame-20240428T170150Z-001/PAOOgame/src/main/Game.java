package main;
import Camera.Camera;
import Database.DatabaseHelper;
import GameWindow.GameWindow;
import Heart.Obj_Heart;
import Heart.SuperObject;
import Tiles.ConcreteTile;
import Tiles.Tile;
import Graphics.Assets;

import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.image.BufferStrategy;
import java.awt.image.BufferedImage;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DecimalFormat;

import static Collision.HelpMethods.*;
import static main.Player.*;

/*! \class Game
    \brief Clasa principala a intregului proiect. Implementeaza Game - Loop (Update -> Draw)

                ------------
                |           |
                |     ------------
    60 times/s  |     |  Update  |  -->{ actualizeaza variabile, stari, pozitii ale elementelor grafice etc.
        =       |     ------------
     16.7 ms    |           |
                |     ------------
                |     |   Draw   |  -->{ deseneaza totul pe ecran
                |     ------------
                |           |
                -------------
    Implementeaza interfata Runnable:

        public interface Runnable {
            public void run();
        }

    Interfata este utilizata pentru a crea un nou fir de executie avand ca argument clasa Game.
    Clasa Game trebuie sa aiba definita metoda "public void run()", metoda ce va fi apelata
    in noul thread(fir de executie). Mai multe explicatii veti primi la curs.

    In mod obisnuit aceasta clasa trebuie sa contina urmatoarele:
        - public Game();            //constructor
        - private void init();      //metoda privata de initializare
        - private void update();    //metoda privata de actualizare a elementelor jocului
        - private void draw();      //metoda privata de desenare a tablei de joc
        - public run();             //metoda publica ce va fi apelata de noul fir de executie
        - public synchronized void start(); //metoda publica de pornire a jocului
        - public synchronized void stop()   //metoda publica de oprire a jocului
 */
public class Game implements Runnable {
    private static Game instance = null; //instanta jocului
    private GameWindow wnd; //fereastra in care se deseneaza jocul
    private boolean runState; //flag ce contine starea firului de executie
    private Thread gameThread; //referinta catre threadul de update si draw al ferestrei
    private BufferStrategy bs; //referinta catre un mecanism cu care se organizeaza memoria complexa ptr un canvas
    private int gameWidth; //lungimea ferestrei
    private int gameHeight; //latimea ferestrei
    private String gameTitle; //titlul
    public Graphics g; //ce folosesc ca sa desenez pe ecran
    public static FirstLevel map; //instantiez mapa
    int speed = 2; //aleg viteza jucatorului
    public static Player pisyna;//instantiez jucatorul
    public String currentDialogue = ""; //folosesc ca sa imi apara dialogul pisidinei catre pisina
    public double timp = 120;//limita de timp pentru a completa jocul
    public BufferedImage heart_full,heart_empty;//imaginile cu vietile jucatorului
    public boolean pressed=false;//selectez optiunea dorita din meniul de optiuni

    public static Game getInstance(String title, int width, int height) {
        //instantiez jocul
        if (instance == null)
            instance = new Game(title, width, height);
        return instance;
    }

    public Game(String title, int width, int height) {
        gameWidth = width; //latimea tabelei
        gameHeight = height; //inaltimea
        gameTitle = title;//titlul tabelei

        wnd = new GameWindow(gameTitle, gameWidth, gameHeight);//am instantiat freastra in care se incarca jocul
        runState = false;
    }

    private void InitGame() {
        //initializez atributele jocului
        wnd = new GameWindow(gameTitle, gameWidth, gameHeight);
        wnd.BuildGameWindow(this);
        Assets.Init();
        wnd.gameState = wnd.playState;

        map = new FirstLevel(gameWidth, gameHeight);
        pisyna = new Player(0, 48);
        //create hearts
        SuperObject heart=new Obj_Heart(g);
        heart_empty=heart.image2;
        heart_full=heart.image1;
        //reincarc starea jocului din baza de date
        loadGameState();
        //cand inchid jocul sa se salveze in baza de date starea jocului
        wnd.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                saveGameState();
                System.exit(0);

            }
        });
    }

    @Override
    public void run() {
        //cum se comporta jocul pe tot parcursul executiei
        InitGame();
        long oldTime = System.nanoTime();
        long currentTime;
        double delta = 0;

        final int framesPerSecond = 60;
        final double timeFrame = 1000000000 / framesPerSecond;
        //cat de repede se actulizeaza jocul
        while (runState == true) {
            currentTime = System.nanoTime();
            delta += (currentTime - oldTime) / timeFrame;
            if (delta >= 1) {
                Update(); //actualizeaza pozitia obiectelor pe harta
                Draw();//deseneaza obiectele pe harta
                delta--;

            }
        }
    }

    public synchronized void StartGame() {
        //inceperea jocului
        if (runState == false) {
            runState = true;
            gameThread = new Thread(this);
            gameThread.start();
        } else {
            return;
        }
    }

    public synchronized void StopGame() {
        //finalizarea jocului
        if (runState == true) {
            runState = false;
            try {
                gameThread.join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        } else {
            return;
        }
    }

    private void Update() {
        //folsesc KeyHandlerul din GameWindow
        KeyHandler kh = wnd.getKeyHandler();
        //cat timp jocul nu e pe pauza
        pressed=kh.pressed;
        if(FirstLevel.currentMap==0)
        {
            if (wnd.gameState == wnd.playState) {
                //actualizez timpul
                timp -= 1. / 60;
                if(timp<=0)
                    wnd.gameState=wnd.lose;
                //tratarea miscarilor realizate de jucator
                if (kh.up == true || kh.down == true || kh.left == true || kh.right == true) {
                    if (kh.up == true) {
                        //miscarea in sus
                        if (CanMoveHere(pisyna.solidArea.x + pisyna.PozX, pisyna.PozY - pisyna.solidArea.y - pisyna.speed, pisyna.solidArea.width, pisyna.solidArea.height, FirstLevel.table0, FirstLevel.currentMap))
                            if (pisyna.PozY - pisyna.speed >= 0) {
                                pisyna.PozY -= speed;
                            }

                        pisyna.direction = "up";

                    } else if (kh.down == true) {
                        //miscarea in jos
                        if (CanMoveHere(pisyna.solidArea.x + pisyna.PozX, pisyna.PozY - pisyna.solidArea.y + pisyna.speed, pisyna.solidArea.width, pisyna.solidArea.height, FirstLevel.table0, FirstLevel.currentMap))
                            if (pisyna.PozY + pisyna.speed <= gameHeight - pisyna.pisynaHeight)
                                pisyna.PozY += speed;
                        pisyna.direction = "down";

                    } else if (kh.right == true) {
                        //miscarea in dreapta
                        if (CanMoveHere(pisyna.solidArea.x + pisyna.PozX + pisyna.speed, pisyna.PozY - pisyna.solidArea.y, pisyna.solidArea.width, pisyna.solidArea.height, FirstLevel.table0, FirstLevel.currentMap))
                            if (pisyna.PozX + pisyna.speed <= gameWidth - pisyna.pisynaWidth)
                                pisyna.PozX += speed;
                        pisyna.direction = "right";

                    } else if (kh.left == true) {
                        //miscarea in stanga
                        if (CanMoveHere(pisyna.solidArea.x + pisyna.PozX - pisyna.speed, pisyna.PozY - pisyna.solidArea.y, pisyna.solidArea.width, pisyna.solidArea.height, FirstLevel.table0, FirstLevel.currentMap))
                            if (pisyna.PozX - pisyna.speed >= 0)
                                pisyna.PozX -= speed;
                        pisyna.direction = "left";

                    }
                    //cat de repede se schimba pozele pisicii astfel incat sa simuleze miscarea
                pisyna.counter++;
                if (pisyna.counter > 12) {
                    if (pisyna.num == 1)
                        pisyna.num = 2;

                    else if (pisyna.num == 2)
                        pisyna.num = 1;
                    pisyna.counter = 0;
                }
                pisyna.Update(1, 1);//update-ul caracterului
                    if (pisyna.PozX >= 0 && pisyna.PozX <= 40 && pisyna.PozY >= 100 && pisyna.PozY <= 144)
                            InteractPisidina(pisyna); //interactiunea cu Pisidina
                pisyna.setDialogue();//dialogul cu pisidina
                if (timp >= 0 && pisyna.PozY >= 456 && pisyna.PozY <= 480 && pisyna.PozX >= 690 && pisyna.PozX <= 720 && FirstLevel.getScore() >=1)
                    wnd.gameState = wnd.win;//tratarea momentului in care se castiga
                if (timp >= 0 && pisyna.PozY >= 456 && pisyna.PozY <= 480 && pisyna.PozX >= 690 && pisyna.PozX <= 720 && FirstLevel.getScore() == 0)
                    wnd.gameState = wnd.lose;//tratarea momentului in care se pierde
                }

        }}
        //tratarea lucrurilor la al doilea nivel
        else if (FirstLevel.currentMap==1) {
            if (wnd.gameState == wnd.playState) {
                if (kh.left == true || kh.right == true) {
                    //miscarile de la al doilea nivel
                    updatePos1(kh);
                        //cat de repede se schimba pozele pisicii astfel incat sa simuleze miscarea
                        pisyna.counter++;
                    if (pisyna.counter > 12) {
                        if (pisyna.num == 1)
                            pisyna.num = 2;

                        else if (pisyna.num == 2)
                            pisyna.num = 1;
                        pisyna.counter = 0;
                    }
                    //System.out.println("PozX: " + pisyna.PozX + " Hitbox X: " + pisyna.hitbox.x);
                    //System.out.println("PozY: " + pisyna.PozY + " Hitbox Y: " + pisyna.hitbox.y);
                    //System.out.println("Checking interaction at level " + FirstLevel.currentMap);

                    pisyna.Update(1, 1);//update-ul caracterului
                    //verificam cand interactioneaza cu pisidina
                    if (pisyna.PozX + pisyna.hitbox.x >= 0 && pisyna.PozX + pisyna.hitbox.x <= 52 && pisyna.hitbox.y >= 479 && pisyna.hitbox.y <= 480)
                        InteractPisidina(pisyna); //interactiunea cu Pisidina
                    pisyna.setDialogue();//dialogul cu pisidina
                    //verificam cand jucatorul pierde
                    if (pisyna.hitbox.y>=710 &&pisyna.hitbox.y<=720&& pisyna.PozX+pisyna.hitbox.x>=240 && pisyna.PozX+pisyna.hitbox.x<=1506)
                        if (wnd.gameState != wnd.lose) {
                            //scadem o viata cand acesta pierde
                            Player.Life--;
                            wnd.gameState = wnd.lose;

                        }
                        //verificam cand jucatorul castiga
                    if (pisyna.PozY+pisyna.hitbox.x >= 1370 && pisyna.hitbox.x+pisyna.PozX<=1466 && pisyna.hitbox.y>=191 && pisyna.hitbox.y<=192)
                        wnd.gameState = wnd.win;//tratarea momentului in care se castiga
                }
            }
        }
        else if (FirstLevel.currentMap==2) {
            //actualizez timpul
            //daca se scurge timpul, pierde
            if(timp<=0)
                wnd.gameState=wnd.lose;
            if (wnd.gameState == wnd.playState) {
                //actualizarea timpului ramas
                timp -= 1. / 60;
                if (kh.left == true || kh.right == true) {
                    //miscarea jucatorului
                    updatePos2(kh);
                    //cat de repede se schimba pozele pisicii astfel incat sa simuleze miscarea
                    pisyna.counter++;
                    if (pisyna.counter > 12) {
                        if (pisyna.num == 1)
                            pisyna.num = 2;

                        else if (pisyna.num == 2)
                            pisyna.num = 1;
                        pisyna.counter = 0;
                    }
                    System.out.println("PozX: " + pisyna.PozX + " Hitbox X: " + pisyna.hitbox.x);
                    System.out.println("PozY: " + pisyna.PozY + " Hitbox Y: " + pisyna.hitbox.y);
                    //System.out.println("Checking interaction at level " + FirstLevel.currentMap);

                    pisyna.Update(1, 1);//update-ul caracteruluiA
                    //verificam cand interactioneaza cu pisidina
                    if (pisyna.PozX + pisyna.hitbox.x >= 0 && pisyna.PozX + pisyna.hitbox.x <= 42 && pisyna.hitbox.y >= 431 && pisyna.hitbox.y <= 432)
                        InteractPisidina(pisyna); //interactiunea cu Pisidina
                    pisyna.setDialogue();//dialogul cu pisidina
                    //verificam cand pierde
                    if (pisyna.hitbox.y >= 671 && pisyna.hitbox.y <= 672 && pisyna.PozX + pisyna.hitbox.x >= 144 && pisyna.PozX + pisyna.hitbox.x <= 1295)
                        if (wnd.gameState != wnd.lose) {
                            //scadem o viata
                            Player.Life--;
                            wnd.gameState = wnd.lose;
                        }
                    //verificam cand castiga
                    if ( pisyna.hitbox.x + pisyna.PozX == 1439 && pisyna.hitbox.y >= 431 && pisyna.hitbox.y <= 432 && Life>0)
                        wnd.gameState = wnd.win;//tratarea momentului in care se castiga*/
                }
            }
        }

            if (wnd.gameState == wnd.pauseState) {
                //nothing
            }
    }
    public void updatePos1(KeyHandler kh)//miscarea de la nivelul 2
    { if (wnd.gameState == wnd.playState) {
        //p.moving=false;
        if (kh.jump)
            pisyna.jump();

        xSpeed = 0;

        if (kh.left) {
            //cand se misca la stanga
            xSpeed -= pisyna.speed;
            pisyna.direction = "left";
        }
        if (kh.right) {
            //cand se misca la dreapta
            xSpeed += pisyna.speed;
            pisyna.direction = "right";
        }
        if (pisyna.hitbox.x + 1 < 1536) {
            //actualizam camera
            Camera.update(pisyna);
        }
        if (!pisyna.inAir) {
            //verificam daca e in aer
            if (!IsEntityOnFloor(pisyna.hitbox, FirstLevel.table1, FirstLevel.currentMap, pisyna)) {
                pisyna.inAir = true;
            }
        }
        if (pisyna.inAir) {
            //daca e in aer
            pisyna.hitbox.y += pisyna.airspeed; // actualizează poziția pe axa Y
            pisyna.airspeed += pisyna.gravity; // aplică gravitația

            // verifică dacă jucătorul a atins solul
            if (IsEntityOnFloor(pisyna.hitbox, FirstLevel.table1, FirstLevel.currentMap, pisyna)) {
                pisyna.inAir = false;
                pisyna.hitbox.y = GetEntityYPosUnderRoofFloor(pisyna.hitbox); // ajustează poziția Y pentru a evita intrarea în sol
                pisyna.airspeed = 0; // resetază viteza verticală
            }
        }
        if (pisyna.inAir) {
            //daca e in aer si  nu avem coliziune
            if (CanMoveHere((int) (pisyna.hitbox.x), (int) (pisyna.hitbox.y + pisyna.airspeed), (int) (pisyna.hitbox.width), (int) (pisyna.hitbox.height), FirstLevel.table1, FirstLevel.currentMap)) {
                pisyna.hitbox.y += pisyna.airspeed;
                pisyna.airspeed += pisyna.gravity;
                updateXPos(xSpeed);
            }
            if (!CanMoveHere((int) (pisyna.hitbox.x), (int) (pisyna.hitbox.y + pisyna.airspeed), (int) (pisyna.hitbox.width), (int) (pisyna.hitbox.height), FirstLevel.table1, FirstLevel.currentMap)) {
                //daca nu e in aer si avem coliziune
                pisyna.hitbox.y = GetEntityYPosUnderRoofFloor(pisyna.hitbox);
                if (pisyna.airspeed > 0) // mergem in jos, lovim ceva
                {
                    pisyna.inAir = false;
                    pisyna.airspeed = 0;
                } else
                    pisyna.airspeed = pisyna.fallSpeedAfterCollision;
                updateXPos(xSpeed);
            }
        } else {
            updateXPos(xSpeed);
        }

        if (!kh.left && !kh.right && !pisyna.inAir)
            return;
    }
    }
    public void updatePos2(KeyHandler kh)//miscarea de la nivelul 3
    { if (wnd.gameState == wnd.playState) {
        //p.moving=false;
        //pisyna.airspeed=0;
        if (kh.jump)
            pisyna.jump();

        xSpeed = 0;

        if (kh.left) {
            //cand se misca la stanga
            xSpeed -= 1;
            pisyna.direction = "left";
        }
        if (kh.right) {
            //cand se misca la dreapta
            xSpeed += 1;
            pisyna.direction = "right";
        }
        if (pisyna.hitbox.x  < 1536) {
            //actualizam camera
            Camera.update(pisyna);
        }
        //System.out.println(Camera.xCamera);
        if (!pisyna.inAir) {
             //verificam daca e in aer
            if (!IsEntityOnFloor(pisyna.hitbox, FirstLevel.table2, FirstLevel.currentMap, pisyna)) {
                pisyna.inAir = true;
            }
        }
        if (pisyna.inAir) {
            //daca e in aer
            pisyna.hitbox.y += pisyna.airspeed; // actualizează poziția pe axa Y
            pisyna.airspeed += pisyna.gravity; // aplică gravitația

            // verifică dacă jucătorul a atins solul
            if (IsEntityOnFloor(pisyna.hitbox, FirstLevel.table2, FirstLevel.currentMap, pisyna)) {
                pisyna.inAir = false;
                pisyna.hitbox.y = GetEntityYPosUnderRoofFloor(pisyna.hitbox); // ajustează poziția Y pentru a evita intrarea în sol
                pisyna.airspeed = 0; // resetază viteza verticală
            }
        }
        if (pisyna.inAir) {
            //daca e in aer si  nu avem si coliziune
            if (CanMoveHere((int) (pisyna.hitbox.x), (int) (pisyna.hitbox.y + pisyna.airspeed), (int) (pisyna.hitbox.width), (int) (pisyna.hitbox.height), FirstLevel.table2, FirstLevel.currentMap)) {
                pisyna.hitbox.y += pisyna.airspeed;
                pisyna.airspeed += pisyna.gravity;
                updateXPos(xSpeed);
            }
            //daca nu e in aer si avem coliziune
            if (!CanMoveHere((int) (pisyna.hitbox.x), (int) (pisyna.hitbox.y + pisyna.airspeed), (int) (pisyna.hitbox.width), (int) (pisyna.hitbox.height), FirstLevel.table2, FirstLevel.currentMap)) {
                pisyna.hitbox.y = GetEntityYPosUnderRoofFloor(pisyna.hitbox);
                if (pisyna.airspeed > 0) // mergem in jos, lovim ceva
                {
                    pisyna.inAir = false;
                    pisyna.airspeed = 0;
                } else
                    pisyna.airspeed = pisyna.fallSpeedAfterCollision;
                updateXPos(xSpeed);
            }
        } else {
            updateXPos(xSpeed);
        }

        if (!kh.left && !kh.right && !pisyna.inAir)
            return;
    }
    }
    private void updateXPos(float xSpeed) {
        //actualizam pozitia pe x
        if(FirstLevel.currentMap==1)
        if(CanMoveHere(pisyna.hitbox.x+xSpeed,pisyna.hitbox.y,pisyna.hitbox.width,pisyna.hitbox.height,FirstLevel.table1,FirstLevel.currentMap))
        {
            //daca nu avem coliziune
            pisyna.hitbox.x += xSpeed;
        }
        else
        {
            pisyna.hitbox.x = GetEntityXPosNextToWall(pisyna.hitbox);
        }
        if(FirstLevel.currentMap==2)
            if(CanMoveHere(pisyna.hitbox.x+xSpeed,pisyna.hitbox.y,pisyna.hitbox.width,pisyna.hitbox.height,FirstLevel.table2,FirstLevel.currentMap))
            {
                //daca nu avem coliziune
                pisyna.hitbox.x += xSpeed;
            }
            else
            {
                pisyna.hitbox.x = GetEntityXPosNextToWall(pisyna.hitbox);
            }
    }

    public void InteractPisidina(Player p) {
        //cazul in care pisina interactioneaza cu pisidina
            wnd.gameState = wnd.dialogueState;
    }

    private void Draw() {
        //deseneaza tot ce tine de joc pe harta
        bs = wnd.GetCanvas().getBufferStrategy();
        if (bs == null) {
            try {
                wnd.GetCanvas().createBufferStrategy(3);
                return;
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        g = bs.getDrawGraphics();
        g.clearRect(0, 0, gameWidth, gameHeight);
        map.loadMap0("/maps/map.txt", 0);//incarca harta
        map.loadMap1("/maps/map02.txt", 1);
        map.loadMap2("/maps/map03.txt", 2);
        map.DrawMap(g);//deseneaza harta
        Graphics2D g2 = (Graphics2D) g;
        pisyna.DrawPlayer(g);//deseneaza jucatorul
        //g.setColor(Color.cyan);
       // g.drawRect(pisyna.solidArea.x,pisyna.solidArea.y,pisyna.solidArea.width,pisyna.solidArea.height);
        if(FirstLevel.currentMap==0)
            g.drawImage(Assets.pisidina, 0, 144, 48, 48, null);//deseneaza caracterul ajutator
        else if(FirstLevel.currentMap==1)
            g.drawImage(Assets.pisidina, 0-Camera.xCamera, 490, 48, 48, null);//deseneaza caracterul ajutator
        else if(FirstLevel.currentMap==2)
            g.drawImage(Assets.pisidina, 0-Camera.xCamera, 440, 48, 48, null);//deseneaza caracterul ajutator
        if(FirstLevel.currentMap==0 || FirstLevel.currentMap==2) {
            Font fnt = new Font("Monospaced", Font.BOLD, 20);
            g.setFont(fnt);
            g.setColor(Color.white);
            DecimalFormat dformat = new DecimalFormat("#0.0");
            g.drawString("timp:" + dformat.format(timp) + "s", 20, 20);//afisarea timpului ramas pe ecran
        }

        Font arial_40 = new Font("Arial", Font.ITALIC, 40);

        g2.setFont(arial_40);
        g2.setColor(Color.white);
        if (wnd.gameState == wnd.playState) {
            if(FirstLevel.currentMap==1 || FirstLevel.currentMap==2)
            drawPlayerLife(); //desenam vietile jucatorului
            //nothing
        }
        if (wnd.gameState == wnd.pauseState) {
            //ce se intampla daca se pune jocul pe pauza
            drawPauseScreen();
            if(FirstLevel.currentMap==1 || FirstLevel.currentMap==2)
            drawPlayerLife();//desenam vietile jucatorului
        }
        //draw dialogue
        if (wnd.gameState == wnd.dialogueState) {
            //ce se intampla daca interactioneaza cu pisidina
            drawScreenDialogue();
            if(FirstLevel.currentMap==1 || FirstLevel.currentMap==2)
            drawPlayerLife();//desenam vietile jucatorului
        }
        if (wnd.gameState == wnd.win)
        {
            Win(pisyna);//ce se intampla daca se castiga nivelul
            if(FirstLevel.currentMap==1 || FirstLevel.currentMap==2)
            drawPlayerLife();//desenam vietile jucatorului
        }

        if (wnd.gameState == wnd.lose)
        { Lose(pisyna);//ce se intampla daca se pierde nivelul
            if(FirstLevel.currentMap==1 || FirstLevel.currentMap==2) {
                drawPlayerLife();//desenam vietile jucatorului
            }
        }
        //options state
        if (wnd.gameState == wnd.optionsState) {
            drawOptionsScreen(); //meniul de optiuni
        }
        bs.show();
        g.dispose();
    }
    public void drawPlayerLife()
    {//functia de desenare a vietilor
        int x= ConcreteTile.Tile_width/2;
        int y=ConcreteTile.Tile_height/2;
        int i=0;
        //deseneaza vietile la max
        while(i<Player.maxLife)
        {
            g.drawImage(heart_empty,x,y,null);
            i++;
            x+=ConcreteTile.Tile_width;
        }
        //resetam
         x=ConcreteTile.Tile_width/2;
         y=ConcreteTile.Tile_height/2;
         i=0;
         //desenam vietile de la inceput
        while(i<Player.Life) {
                g.drawImage(heart_full,x,y,null);
            i++;
            x+=ConcreteTile.Tile_width;
        }

    }
    public void drawPauseScreen() {
        //afisarea textului aferent pauzei
        String text = "PAUZĂ";
        int length = (int) g.getFontMetrics().getStringBounds(text, g).getWidth();
        int y = gameHeight / 2;
        int x = gameWidth / 2 - length / 2;
        g.drawString(text, x, y);
    }

    public void drawScreenDialogue() {
        //afisarea casetei de dialog aferente
        int x = ConcreteTile.Tile_height * 2;
        int y = ConcreteTile.Tile_height / 2;
        int width = 768 - (ConcreteTile.Tile_width * 4);
        int height = ConcreteTile.Tile_height * 5;
        g.setFont(g.getFont().deriveFont(Font.PLAIN, 20));
        drawSubWindow(x, y, height, width);
        x += ConcreteTile.Tile_width;
        y += ConcreteTile.Tile_height;
        currentDialogue = pisyna.dialogue[0];
        for (String line : currentDialogue.split("\n")) {
            //incadrarea textului in fereastra destinata dialogului
            g.drawString(line, x, y);
            y += 40;
        }
    }

    public void drawSubWindow(int x, int y, int height, int width) {
        //realizarea casetei text
        Color c = new Color(0, 0, 0, 150);
        g.setColor(c);
        g.fillRoundRect(x, y, width, height, 40, 40);

        c = new Color(255, 255, 255);
        g.setColor(c);
        Graphics2D g2 = (Graphics2D) g;
        g2.setStroke(new BasicStroke(5));
        g2.drawRoundRect(x + 5, y + 5, width - 10, height - 10, 25, 25);

    }

    public void Win(Player p) {
        //tratarea cazului in care se castiga nivelul
        String text="";
        if(FirstLevel.currentMap==0 || FirstLevel.currentMap==1)
            text = "Treci la nivelul următor";
        if(FirstLevel.currentMap==2)
            text="AI CÂȘTIGAT!!!!!";
        int length = (int) g.getFontMetrics().getStringBounds(text, g).getWidth();
        int y = gameHeight / 2;
        int x = gameWidth / 2 - length / 2;
        g.drawString(text, x, y);
        if(FirstLevel.currentMap==0)
        new Thread(() -> {
            try {
                Thread.sleep(5000);
                // treci la nivelul 2
                teleport(1, 0, 48); // exemplu de trecere la nivelul următor
                wnd.gameState = wnd.playState; // setează starea jocului la starea de joc
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }).start();
        if(FirstLevel.currentMap==1)
            new Thread(() -> {
                try {
                    Thread.sleep(5000);
                    // treci la nivelul 3
                    teleport(2, 0, 48); // exemplu de trecere la nivelul următor
                    pisyna.resetState();
                    wnd.gameState = wnd.playState; // setează starea jocului la starea de joc
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }).start();
        if(FirstLevel.currentMap==2)
            new Thread(() -> {
                try {//// treci la nivelul 1 iar
                    Thread.sleep(5000);
                    FirstLevel.currentMap=0;
                    timp=120;
                    pisyna.PozX=0;
                    pisyna.PozY=48;
                    pisyna.direction="right";
                    FirstLevel.score=0;
                    map.DrawCompass();
                    wnd.gameState = wnd.playState; // setează starea jocului la starea de joc
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }).start();
    }

    public void Lose(Player p) {
        //tratarea cazului in care se pierde nivelul

        String text = "AI PIERDUT!";
        int length = (int) g.getFontMetrics().getStringBounds(text, g).getWidth();
        int y = gameHeight / 2;
        int x = gameWidth / 2 - length / 2;
        g.drawString(text, x, y);
        if(FirstLevel.currentMap==0)
            //se reia nivelul 1
            new Thread(() -> {
                try {
                    Thread.sleep(5000);
                    //setam totul ca sa fie ca la inceput
                    timp=120;
                    pisyna.PozX=0;
                    pisyna.PozY=48;
                    pisyna.direction="right";
                    FirstLevel.score=0;
                    map.DrawCompass();
                    wnd.gameState = wnd.playState; // Setează starea jocului la starea de joc
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }).start();
        if(FirstLevel.currentMap==1)
            //se reia nivelul 2
        new Thread(() -> {
            try {
                //setam totul ca sa fie ca la inceput
                Thread.sleep(5000);
                Camera.xCamera=0;
                pisyna.hitbox.x=12;
                pisyna.hitbox.y=48;
                if(Life==0)
                    Life=maxLife;
                pisyna.direction="right";
                wnd.gameState = wnd.playState; // Setează starea jocului la starea de joc
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }).start();
        if(FirstLevel.currentMap==2)
            //se reia nivelul 3
            new Thread(() -> {
                try {
                    //setam totul ca sa fie ca la inceput
                    Thread.sleep(5000);
                    timp=120;
                    Camera.xCamera=0;
                    pisyna.hitbox.x=12;
                    pisyna.hitbox.y=48;
                    pisyna.direction="right";
                    if(Life==0)
                        Life=maxLife;
                    wnd.gameState = wnd.playState; // Setează starea jocului la starea de joc
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }).start();
    }

    public void drawOptionsScreen() {
        //desenarea meniului de optiuni
        g.setColor(Color.white);
        g.setFont(g.getFont().deriveFont(32F));

        //sub window
        int frameX = ConcreteTile.Tile_height * 3;
        int frameY = ConcreteTile.Tile_height;
        int frameWidth = ConcreteTile.Tile_width * 8;
        int frameHeight = ConcreteTile.Tile_height * 10;
        drawSubWindow(frameX, frameY, frameHeight, frameWidth);
        if (wnd.subState==0) {
                String text = "Opțiuni";
                int length = (int) g.getFontMetrics().getStringBounds(text, g).getWidth();
                int textY = frameY + ConcreteTile.Tile_height;
                int textX = getXForCenteredText(text, g);
                g.drawString(text, textX, textY);
                textX = frameX + ConcreteTile.Tile_width;
                textY += ConcreteTile.Tile_height * 2;
                g.drawString("Reluare joc", textX, textY);
                //ce se intampla daca se alege optiunea Reluare joc
                if (wnd.commandNum == 0) {
                    g.drawString(">", textX - 25, textY);
                    if(pressed==true)
                    {
                        //se reia nivelul 1
                        FirstLevel.currentMap=0;
                        map = new FirstLevel(gameWidth, gameHeight);
                        pisyna = new Player(0, 48);
                        pisyna.DrawPlayer(g);
                        wnd.commandNum = 0;
                        map.loadMap0("/maps/map.txt", 0);//incarca harta
                        map.DrawMap(g);
                        g.drawImage(Assets.pisidina, 0, 144, 48, 48, null);
                        timp = 120;
                        pisyna.direction = "right";
                        FirstLevel.score = 0;
                        map.DrawCompass();
                        Camera.xCamera=0;
                        wnd.gameState = wnd.playState;
                        pressed=false;
                    }

                }
                textY += ConcreteTile.Tile_height;
                g.drawString("Reluare nivel", textX, textY);
                //ce se intampla daca se alege optiunea Reluare Nivel
                if (wnd.commandNum == 1) {
                    g.drawString(">", textX - 25, textY);
                    if(pressed==true)
                    {  //se reia nivelul 1
                        if(FirstLevel.currentMap==0) {

                            timp = 120;
                            pisyna.PozX = 0;
                            pisyna.PozY = 48;
                            pisyna.direction = "right";
                            FirstLevel.score = 0;
                            map.DrawCompass();
                            wnd.gameState = wnd.playState;
                            Camera.xCamera=0;
                            pisyna.hitbox.x=12;
                            pisyna.hitbox.y=48;

                        }
                        //se reia nivelul 2

                    else if(FirstLevel.currentMap==1)
                    {
                        Camera.xCamera=0;
                        pisyna.hitbox.x=12;
                        pisyna.hitbox.y=48;
                        if(Life==0)
                            Life=maxLife;
                        pisyna.direction="right";
                        wnd.gameState = wnd.playState;
                        if(Life==0)
                        Life=maxLife;
                    }
                    //se reia nivelul 3
                    else if(FirstLevel.currentMap==2)
                    {
                        timp=120;
                        Camera.xCamera=0;
                        pisyna.hitbox.x=12;
                        pisyna.hitbox.y=48;
                        pisyna.direction="right";
                        if(Life==0)
                            Life=maxLife;
                        wnd.gameState = wnd.playState;
                    }
                    pressed=false;
                    }
                }
                textY += ConcreteTile.Tile_height;
                g.drawString("Ieșire", textX, textY);
                if (wnd.commandNum == 2) {
                    g.drawString(">", textX - 25, textY);
                    if (pressed == true) {
                        //se inchide jocul
                        saveGameState();
                       System.exit(0);
                        pressed = false;
                    }
                }
                textY +=ConcreteTile.Tile_height * 3;
                g.drawString("Înapoi", textX, textY);
                if (wnd.commandNum == 3) {
                    g.drawString(">", textX - 25, textY);
                    if(pressed==true) {
                       //iese din meniul de optiuni
                        wnd.gameState = wnd.playState;
                        pressed=false;
                    }
                }
        }


    }

    public int getXForCenteredText(String text, Graphics g) {
        //functie sa puna textul in centru
        int length = (int) g.getFontMetrics().getStringBounds(text, g).getWidth();
        int x = gameWidth / 2 - length / 2;
        return x;
    }

    public void teleport(int map, int x, int y) {
        FirstLevel.currentMap = map;
        if(map==1) {
            //teleportam jucatorul la nivelul 2
            pisyna.PozX = x;
            pisyna.PozY = y;
            pisyna.hitbox.x=12;
            pisyna.hitbox.y=48;
            Camera.xCamera=0;
        }
        if(map==2) {
            //teleportam jucatorul la nivelul 3
            timp=120;
            Camera.xCamera=0;
            pisyna.hitbox.x=12;
            pisyna.hitbox.y=48;
            pisyna.airspeed=0;
            pisyna.jumpSpeed=-3.5f;
            pisyna.gravity=0.03f;
            pisyna.fallSpeedAfterCollision=0.5f;
        }
    }
    public static Player getPlayer()
    {
        return pisyna;
    }
    public void windowsFocusLost()
    {
        //pisyna.resetDirBooleans();
    }
    public void saveGameState() {
        //functie pentru a salva starea jocului in baza de date
        Connection conn = null;
        try {
            Class.forName("org.sqlite.JDBC");
            System.out.println("driver-ul a fost încarcat");
            conn = DriverManager.getConnection(DatabaseHelper.URL);
            System.out.println("conexiunea la baza de date a fost stabilita");
            DatabaseHelper.createTables(conn);
            System.out.println("tabelul a fost creat");
            DatabaseHelper.insertData(conn, FirstLevel.currentMap, pisyna.PozX, pisyna.PozY, Player.Life, FirstLevel.getScore(), timp,
                    pisyna.hitbox.x, pisyna.hitbox.y, pisyna.airspeed, pisyna.jumpSpeed, pisyna.gravity, pisyna.fallSpeedAfterCollision,Camera.xCamera);
            System.out.println("starea jocului a fost inserata cu succes");
        } catch (ClassNotFoundException e) {
            System.out.println("driver-ul nu a fost gasit " + e.getMessage());
        } catch (SQLException e) {
            System.out.println("eroare la salvarea starii jocului " + e.getMessage());
        } finally {
            try {
                if (conn != null) {
                    conn.close();
                    System.out.println("conexiunea la baza de date a fost inchisa");
                }
            } catch (SQLException ex) {
                System.out.println("eroare la închiderea conexiunii la baza de date " + ex.getMessage());
            }
        }
    }

    private void loadGameState() {
        //functie pentru incarcarea starii din baza de date
        Connection conn = null;
        try {
            Class.forName("org.sqlite.JDBC");
            conn = DriverManager.getConnection(DatabaseHelper.URL);
            ResultSet rs = DatabaseHelper.readLastGameState(conn);
            if (rs.next()) {
                int currentMap = rs.getInt("current_map");
                int posX = rs.getInt("posX");
                int posY = rs.getInt("posY");
                int health = rs.getInt("health");
                int score = rs.getInt("score");
                double timeLeft = rs.getDouble("time_left");
                float hitbox_x = rs.getFloat("hitbox_x");
                float hitbox_y = rs.getFloat("hitbox_y");
                float airspeed = rs.getFloat("airspeed");
                float jumpSpeed = rs.getFloat("jumpSpeed");
                float gravity = rs.getFloat("gravity");
                float fallSpeedAfterCollision = rs.getFloat("fallSpeedAfterCollision");
                int xCamera = rs.getInt("xCamera");

                // Setează starea jocului
                FirstLevel.currentMap = currentMap;
                pisyna.PozX = posX;
                pisyna.PozY = posY;
                Player.Life = health;
                FirstLevel.setScore(score);
                timp = timeLeft;
                pisyna.hitbox.x = hitbox_x;
                pisyna.hitbox.y = hitbox_y;
                Camera.xCamera=xCamera;
                if(FirstLevel.currentMap==1) {
                    pisyna.airspeed = 0;
                    pisyna.jumpSpeed = -4f;
                    pisyna.gravity = 0.06f;
                    pisyna.fallSpeedAfterCollision = 0.5f;
                }
                else if(FirstLevel.currentMap==2) {
                    pisyna.airspeed=0;
                    pisyna.jumpSpeed=-3.5f;
                    pisyna.gravity=0.03f;
                    pisyna.fallSpeedAfterCollision=0.5f;
                }
                System.out.println("starea jocului a fost incarcata cu succes");
            } else {
                System.out.println("nu a fost găsita nicio stare a jocului salvata anterior");
            }
        } catch (ClassNotFoundException e) {
            System.out.println("driver nu a fost gasit " + e.getMessage());
        } catch (SQLException e) {
            System.out.println("eroare la încărcarea starii jocului " + e.getMessage());
        } finally {
            try {
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException ex) {
                System.out.println("eroare la inchiderea conexiunii la baza de date " + ex.getMessage());
            }
        }
    }

}




