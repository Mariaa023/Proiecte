package main;

import Camera.Camera;
import GameWindow.GameWindow;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.security.Key;

public class KeyHandler implements KeyListener {
    GameWindow g;
    //tratarea cazului in care este apasata o tasta
    public KeyHandler(GameWindow g)
    {
        this.g=g;
    }
    public boolean up;
    public boolean down;
    public boolean right;
    public boolean left;
    public boolean jump;
    public boolean pressed;

    @Override
    public void keyTyped(KeyEvent e)
    {

    }
    @Override
    public void keyPressed(KeyEvent e) {
        int code = e.getKeyCode();
        //play state
        if(g.gameState==g.playState)
        {
            if (code == KeyEvent.VK_W) {
                up = true;

            }
            if (code == KeyEvent.VK_A) {
                left = true;
                //cand se misca si camera la nivele 2 si 3
                if(FirstLevel.currentMap==1 || FirstLevel.currentMap==2)
                    Camera.moveLeft=true;
            }
            if (code == KeyEvent.VK_S) {
                down = true;
            }
            if (code == KeyEvent.VK_D) {
                right = true;
                //cand se misca si camera la nivelele 2 si 3
                if(FirstLevel.currentMap==1 || FirstLevel.currentMap==2)
                    Camera.moveRight=true;


            }
            if(code==KeyEvent.VK_R)
            {
                //saritura
                jump=true;
            }
            if (code == KeyEvent.VK_SPACE) {
                //intram in pauza
                g.gameState = g.pauseState;

            }
            if(code==KeyEvent.VK_ESCAPE)
            {
                //intram in meniul de optiuni
                g.gameState=g.optionsState;
            }
        }
        //pause state
        else if(g.gameState==g.pauseState)
        {
            //iesim din pauza
            if (code == KeyEvent.VK_SPACE)
                g.gameState = g.playState;


        }
        //dialogue state
        else if(g.gameState==g.dialogueState)
        {
            //iesim din dialog

            if(code==KeyEvent.VK_ENTER)
            {
                g.gameState=g.playState;
            }

        }
        else if(g.gameState==g.optionsState)
        {
            //iesim din meniul de optiuni
            if(code==KeyEvent.VK_ESCAPE)
                g.gameState=g.playState;
            //alegem ce dorim din meniul de optiuni
            if(code== KeyEvent.VK_O)
                pressed=true;
            //cum se actualizeaza sageata din fata optiunii
            int maxComandNum=0;
            switch(g.subState)
            {
                case 0:
                    maxComandNum=3;
            }
            if(code==KeyEvent.VK_W)
            {
                g.commandNum--;
                if(g.commandNum<0)
                    g.commandNum=maxComandNum;
            }
            if(code==KeyEvent.VK_S)
            {
                g.commandNum++;
                if(g.commandNum>maxComandNum)
                {
                    g.commandNum=0;
                }
            }
        }

    }
        @Override
        public void keyReleased (KeyEvent e) {
            int code = e.getKeyCode();
            if (code == KeyEvent.VK_W) {
                up = false;
            }
            if (code == KeyEvent.VK_A) {
                left = false;
                //cand nu se mai misca camera la nivele 2 si 3
                if(FirstLevel.currentMap==1 || FirstLevel.currentMap==2)
                    Camera.moveLeft=false;


            }
            if (code == KeyEvent.VK_S) {
                down = false;
            }
            if (code == KeyEvent.VK_D) {
                right = false;
                //cand nu se mai misca camera la nivele 2 si 3
                if(FirstLevel.currentMap==1 || FirstLevel.currentMap==2)
                    Camera.moveRight=false;


            }
            if(code==KeyEvent.VK_R)
                //nu mai sare
                jump=false;
            if(code==KeyEvent.VK_O)
                //nu mai e optiunea selectata
                pressed=false;

        }


}
