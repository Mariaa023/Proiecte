package main;

public class Main {
    public static void main(String[] args) {
        //instantierea jocului
        Game paooGame=Game.getInstance("Pisimania", 768, 768);
        paooGame.StartGame();
    }
}
