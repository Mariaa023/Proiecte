package main;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;

import Camera.Camera;
import GameWindow.GameWindow;
import Graphics.Assets;
import Tiles.ConcreteTile;
import Tiles.Tile;

import java.awt.*;
public class Player
{ public final int pisynaWidth=48;//lungimea sprite-ului pisicii
public final int pisynaHeight=32;//latimea sprite-ului pisicip
public int PozX;//pozitia x pe harta
public int PozY;//pozitia y pe harta
public  int speed;//viteza jucatorului
public String direction="right";//in ce directie se indreapta cand apare pe harta
public int counter=0;//ajuta la schimbarea sprite-ului ca sa simuleze miscarea
public int num=1;//ajuta la schimbarea sprite-ului ca sa simuleze miscarea
public Rectangle solidArea=new Rectangle(12,24,24,24);//coliziune
String dialogue[]=new String[20];//textul spus de pisidina
public BufferedImage img;//imagine
public Rectangle2D.Float hitbox;//de implementat coliziunea la nivelele 2 si 3
//jumping/gravity
public float airspeed=0f;//viteza in aer
public float gravity=0.06f;//gravitatia
public float jumpSpeed=-4f;//viteza cu care sare
public float fallSpeedAfterCollision=0.5f;//viteza cu care cade
public boolean inAir=false;//daca e in aer sau nu
public static float xSpeed;//pentru miscare la saritura
private float xDrawOffset=3;//cat taie din tile ul pisicii
//camera
    private int maxTilesOffsetwidth;//cate tile uri sunt maxim
    public int maxlvlOffsetX=maxTilesOffsetwidth* ConcreteTile.Tile_width;
    //character status
    public  static int maxLife;//nr maxim de vieti
    public  static int Life;//viata curenta
public Player(int x,int y)
{
    //instantierea jucatorului
    this.PozX=x;
    this.PozY=y;
    //initializam hitbox ul
    initHitbox(PozX,PozY,48,48);
    speed=2;
    img=Assets.pisyna[0][4];
    this.maxlvlOffsetX = (FirstLevel.maxWorldCol * ConcreteTile.Tile_width) - GameWindow.GetWndWidth();
    //player status
    maxLife=3;
    Life=maxLife;

}
public void initHitbox(float x,float y,float width,float height)
{
    hitbox = new Rectangle2D.Float(x, y, width, height);
}
public void resetState()
{
    //resetam vietile maxime
    Life=maxLife;
}
public void Update(int x,int y)
{
    //actualizarea jucatorului daca a gasit vreo busola
    img=Assets.pisyna[x][y];

     if(CheckIfScored(PozX,PozY))
         Game.map.SelectCompass(PozX,PozY);
     else if(CheckIfScored(PozX,PozY+pisynaHeight))
         Game.map.SelectCompass(PozX,PozY+pisynaHeight);
     else if(CheckIfScored(PozX+pisynaWidth,PozY))
         Game.map.SelectCompass(PozX+pisynaWidth,PozY);
     else if(CheckIfScored(PozX+pisynaWidth,PozY+pisynaHeight))
         Game.map.SelectCompass(PozX+pisynaWidth,PozY+pisynaHeight);
}
public void setDialogue()
{
    //cuvintele spuse de catre pisidina la fiecare nivel
    if(FirstLevel.currentMap==0)
        dialogue[0]="Bună, Pisina! În acest nivel trebuie să colectezi busola \n și să ieși din labirint în mai puțin de 2 minute! \n Multă baftă!";
    else if(FirstLevel.currentMap==1)
        dialogue[0]="Bună, Pisina! În acest nivel trebuie să sari pe nori \n ca să ieși din Pisiland și să ajungi acasă. \n Folosește-ți cu înțelepciune cele 3 vieți! \n Multă baftă!";
    else if(FirstLevel.currentMap==2)
        dialogue[0]="Bună, Pisina! În acest nivel trebuie să ai grijă \n să nu cazi în bălțile cu otravă puse de Pisiboss. \n Pe lângă asta, fii atentă la timpul rămas! \n Multă baftă! ";
}
public void DrawPlayer(Graphics g)
{
    //desenarea jucatorului pe ecran ca sa simuleze miscarea
        BufferedImage image = null;
        switch (direction) {
            case "up":
                if (num == 1) {
                    image = Assets.pisyna[7][0];
                }
                if (num == 2) {
                    image = Assets.pisyna[7][2];
                }
                break;
            case "down":
                if (num == 1) {
                    image = Assets.pisyna[4][0];
                }
                if (num == 2) {
                    image = Assets.pisyna[4][2];
                }
                break;
            case "left":
                if (num == 1) {
                    image = Assets.pisyna[5][0];
                }
                if (num == 2) {
                    image = Assets.pisyna[5][2];
                }
                break;
            case "right":
                if (num == 1) {
                    image = Assets.pisyna[6][0];
                }
                if (num == 2) {
                    image = Assets.pisyna[6][2];
                }
                break;

        }
        //desenarea in functie de fiecare nivel a jucatorului
        if(FirstLevel.currentMap==0)
            g.drawImage(image, PozX, PozY, 48, 48, null);
        else if(FirstLevel.currentMap==1)
        g.drawImage(image, (int)(PozX+hitbox.x-xDrawOffset-Camera.xCamera), (int)(hitbox.y), 48, 48, null);
        else if(FirstLevel.currentMap==2)
            g.drawImage(image, (int)(PozX+hitbox.x-xDrawOffset-Camera.xCamera), (int)(hitbox.y), 48, 48, null);
}
public boolean CheckIfScored(int x,int y) {
    //daca jucatorul gaseste vreo busola pe traseu
    int x1 = x;
    int y1 = y;

    int x2 = x1 + pisynaWidth;
    int y2 = x2 + pisynaHeight;
    if(FirstLevel.isCompass(x1,y1))
        return true;
    if(FirstLevel.isCompass(x2,y1))
        return true;
    if(FirstLevel.isCompass(x1,y2))
        return true;
    if(FirstLevel.isCompass(x2,y2))
        return true;
    return false;
}
public void jump()
{
    //functia de realizat saritura
    if(inAir)
        return;
    inAir=true;
    airspeed=jumpSpeed;
}

}