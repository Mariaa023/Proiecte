package Database;
import java.sql.*;

public class DatabaseHelper {
//calea absoluta catre baza mea de date
    public static final String URL = "jdbc:sqlite:C:/Users/maria/Desktop/PAOOgame-20240428T170150Z-001/GAME_STATE.db";
//stabilirea conexiunii dintre baza de date si proiectul meu
    public static void connect() {
        Connection conn = null;
        try {
            Class.forName("org.sqlite.JDBC");
            //se incearca conexiunea dintre cele doua
            conn = DriverManager.getConnection(URL);
            System.out.println("conexiunea a fost stabilită");

            // apelarea metodei de creare a tabelelor
            createTables(conn);

        } catch (ClassNotFoundException e) {
            System.out.println("nu a fost gasita baza " + e.getMessage());
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        } finally {
            try {
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException ex) {
                System.out.println(ex.getMessage());
            }
        }
    }

    public static void createTables(Connection conn) {
        //sterge tabelul creat si face altul
        String sqlDropGameStates = "DROP TABLE IF EXISTS GameStates";
        //cream noul tabel
        String sqlCreateGameStates =
                "CREATE TABLE GameStates (" +
                        "state_id INTEGER PRIMARY KEY AUTOINCREMENT," +
                        "current_map INTEGER NOT NULL," +
                        "posX INTEGER NOT NULL," +
                        "posY INTEGER NOT NULL," +
                        "health INTEGER NOT NULL," +
                        "score INTEGER NOT NULL," +
                        "time_left REAL NOT NULL," +
                        "hitbox_x REAL NOT NULL," +
                        "hitbox_y REAL NOT NULL," +
                        "airspeed REAL NOT NULL," +
                        "jumpSpeed REAL NOT NULL," +
                        "gravity REAL NOT NULL," +
                        "fallSpeedAfterCollision REAL NOT NULL," +
                        "xCamera INTEGER NOT NULL" +
                        ");";

        try (Statement stmt = conn.createStatement()) {
            stmt.execute(sqlDropGameStates); //sterge tabelul existent
            stmt.execute(sqlCreateGameStates); //creeaza noul tabel
            System.out.println("tabel creat cu succes");
        } catch (SQLException e) {
            System.out.println("eroare la crearea tabelului " + e.getMessage());
        }
    }



//insereaza noile date in baza de date
    public static void insertData(Connection conn, int currentMap, int posX, int posY, int health, int score, double timeLeft,
                                  float hitbox_x, float hitbox_y, float airspeed, float jumpSpeed, float gravity, float fallSpeedAfterCollision, float xCamera) throws SQLException {
        String sql = "INSERT INTO GameStates(current_map, posX, posY, health, score, time_left, hitbox_x, hitbox_y, airspeed, jumpSpeed, gravity, fallSpeedAfterCollision, xCamera) " +
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, currentMap);
            pstmt.setInt(2, posX);
            pstmt.setInt(3, posY);
            pstmt.setInt(4, health);
            pstmt.setInt(5, score);
            pstmt.setDouble(6, timeLeft);
            pstmt.setFloat(7, hitbox_x);
            pstmt.setFloat(8, hitbox_y);
            pstmt.setFloat(9, airspeed);
            pstmt.setFloat(10, jumpSpeed);
            pstmt.setFloat(11, gravity);
            pstmt.setFloat(12, fallSpeedAfterCollision);
            pstmt.setFloat(13, xCamera);

            pstmt.executeUpdate();
            System.out.println("stare joc inserata cu succes");
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

//citim ultimele date din baza de date
    public static ResultSet readLastGameState(Connection conn) throws SQLException {
        String sql = "SELECT * FROM GameStates ORDER BY state_id DESC LIMIT 1";
        Statement stmt = conn.createStatement();
        return stmt.executeQuery(sql);
    }
//apelam functia care creeaza conexiunea
    public static void main(String[] args) {
        connect();
    }

}
