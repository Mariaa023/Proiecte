function incarcaPersoane(){
    var x=new XMLHttpRequest();
    x.onreadystatechange=function(){
        if(this.readyState==4 && this.status==200)
            proceseazaXML(this);
    };
    x.open("GET","resurse/persoane.xml",true);
    x.send();
}
function proceseazaXML(xml) {
    var xmlDoc = xml.responseXML;
    var persoane = xmlDoc.getElementsByTagName("persoana");
    var html = '<table class="tabel-persoane">';
    
    // Antet tabel adaptat la structura XML
    html += '<tr><th>ID</th><th>Nume</th><th>Prenume</th><th>Vârstă</th><th>Telefon</th><th>Adresă</th></tr>';
    
    for (var i = 0; i < persoane.length; i++) {
        var persoana = persoane[i];
        
        // Extrage datele cu verificări
        var id = persoana.getAttribute('id') || 'N/A';
        var nume = persoana.getElementsByTagName("nume")[0]?.textContent || 'N/A';
        var prenume = persoana.getElementsByTagName("prenume")[0]?.textContent || 'N/A';
        var varsta = persoana.getElementsByTagName("varsta")[0]?.textContent || 'N/A';
        var telefon = persoana.getElementsByTagName("telefon")[0]?.textContent || 'N/A';
        
        // Procesează adresa imbricată
        var adresaElem = persoana.getElementsByTagName("adresa")[0];
        var adresa = adresaElem ? 
            `${adresaElem.getElementsByTagName("strada")[0]?.textContent || ''} ${adresaElem.getElementsByTagName("numar")[0]?.textContent || ''}, ${adresaElem.getElementsByTagName("localitate")[0]?.textContent || ''}` : 
            'N/A';
        
        html += `<tr>
            <td>${id}</td>
            <td>${nume}</td>
            <td>${prenume}</td>
            <td>${varsta}</td>
            <td>${telefon}</td>
            <td>${adresa}</td>
        </tr>`;
    }
    
    html += '</table>';
    document.getElementById("continut").innerHTML = html;
}