let canvas, context;
let startX, startY;
let desenare = false; 
let dreptunghiuri = []; 

function start() {
  initializare();
  detalii();
  setInterval(actualizeazaTimp, 1000);
  deseneazaContinutInitial();
}

function detalii() {
  const dataCurenta = new Date();
  document.getElementById("data").innerHTML = dataCurenta.toLocaleTimeString();
  document.getElementById("url").innerHTML = window.location.href;
  
  if (!navigator.geolocation) {
      document.getElementById("locatie").innerHTML = "Browserul nu suportă geolocația";
      return;
  }

  if (navigator.geolocation) {
    navigator.geolocation.getCurrentPosition(
        pozitie => {
            const locatie = `Latitudine: ${pozitie.coords.latitude}, Longitudine: ${pozitie.coords.longitude}`;
            document.getElementById('locatie').innerHTML = locatie;
        },
        eroare => {
            document.getElementById('locatie').innerHTML = 
                "Locația nu este disponibilă: " + eroare.message;
        }
    );
  } else {
    document.getElementById('locatie').innerHTML = 
        "Geolocația nu este suportată de browser";
  }
  
  const userAgent = navigator.userAgent;
  let browser, versiune;

  if (userAgent.includes("Firefox")) {
      browser = "Mozilla Firefox";
      versiune = userAgent.match(/Firefox\/(\d+\.\d+)/)[1];
  } else if (userAgent.includes("Edg")) {
      browser = "Microsoft Edge";
      versiune = userAgent.match(/Edg\/(\d+\.\d+)/)[1];
  } else if (userAgent.includes("Chrome")) {
      browser = "Google Chrome";
      versiune = userAgent.match(/Chrome\/(\d+\.\d+)/)[1];
  } else if (userAgent.includes("Safari")) {
      browser = "Apple Safari";
      versiune = userAgent.match(/Version\/(\d+\.\d+)/)[1];
  } else {
      browser = "Browser necunoscut";
      versiune = "N/A";
  }
  
  document.getElementById("browser").innerHTML = 
  `Browser: ${browser} (Versiunea: ${versiune})`;

  let sistemOperare = "Necunoscut";
  if (userAgent.includes("Windows")) sistemOperare = "Windows";
  else if (userAgent.includes("Mac")) sistemOperare = "macOS";
  else if (userAgent.includes("Linux")) sistemOperare = "Linux";
  else if (userAgent.includes("Android")) sistemOperare = "Android";
  else if (userAgent.includes("iOS")) sistemOperare = "iOS";

  document.getElementById('info').innerHTML = sistemOperare;
}

function initializare() {
    canvas = document.getElementById('canvas');
    context = canvas.getContext('2d');
    
    canvas.addEventListener('mousedown', gestioneazaApasareMouse);
    canvas.addEventListener('mouseup', gestioneazaRidicareMouse);
}

function gestioneazaApasareMouse(event) {
    startX = event.offsetX;
    startY = event.offsetY;
    desenare = true; 
}

function gestioneazaRidicareMouse(event) {
    if (!desenare) return; 
    
    const endX = event.offsetX;
    const endY = event.offsetY;
    
    dreptunghiuri.push({
        x1: Math.min(startX, endX),
        y1: Math.min(startY, endY),
        x2: Math.max(startX, endX),
        y2: Math.max(startY, endY),
        culoareContur: document.getElementById('margine').value,
        culoareUmplere: document.getElementById('umplere').value
    });
    
    redeseneazaCanvas();
    desenare = false; 
}

function deseneazaDreptunghi(dreptunghi) {
    const latime = dreptunghi.x2 - dreptunghi.x1;
    const inaltime = dreptunghi.y2 - dreptunghi.y1;
    
    context.strokeStyle = dreptunghi.culoareContur;
    context.fillStyle = dreptunghi.culoareUmplere;
    context.lineWidth = 3;
    
    context.beginPath();
    context.rect(dreptunghi.x1, dreptunghi.y1, latime, inaltime);
    context.fill();
    context.stroke();
}

function redeseneazaCanvas() {
    context.clearRect(0, 0, canvas.width, canvas.height);
    
    deseneazaContinutInitial();
    
    dreptunghiuri.forEach(dreptunghi => {
        deseneazaDreptunghi(dreptunghi);
    });
}

function deseneazaContinutInitial() {
    context.font = '16px Arial';
    context.fillStyle = '#0000102';
    context.fillText('Desenează aici!', 10, 30);
}

function stergeCanvas() {
    dreptunghiuri = [];
    context.clearRect(0, 0, canvas.width, canvas.height);
    deseneazaContinutInitial();
}

function actualizeazaTimp() {
    document.getElementById("data").innerHTML = new Date().toLocaleTimeString();
}

function adaugaLinie() {
  const tabel = document.getElementById('tabel');
  const pozitie = parseInt(document.getElementById('pozitie').value);
  const model = document.getElementById('model').value;
  const marime = document.getElementById('marime').value;
  const culoarePantof = document.getElementById('culoarePantof').value;
  const pret = document.getElementById('pret').value;
  const stoc = document.getElementById('stoc').value;
  const culoareFundal = document.getElementById('culoare').value;
  if (isNaN(pozitie) || pozitie < 2 || pozitie > tabel.rows.length + 1) {
      alert('Introduceți o poziție validă pentru linie (între 2 și ' + (tabel.rows.length + 1) + ')');
      return;
  }

  if (!model || !marime || !culoarePantof || !pret || !stoc) {
      alert('Completați toate câmpurile!');
      return;
  }
  const randNou = tabel.insertRow(pozitie - 1); 
 const celule = [
      model,
      marime,
      culoarePantof,
      pret + ' lei',
      stoc + ' buc'
  ];
celule.forEach((valoare, index) => {
      const celulaNoua = randNou.insertCell(index); 
      celulaNoua.textContent = valoare;
      celulaNoua.style.backgroundColor = culoareFundal;
  });
  document.getElementById('model').value = '';
  document.getElementById('marime').value = '';
  document.getElementById('culoarePantof').value = '';
  document.getElementById('pret').value = '';
  document.getElementById('stoc').value = '';
}

function adaugaColoana() {
  const tabel = document.getElementById('tabel');
  const pozitie = parseInt(document.getElementById('pozitie').value);
  const culoare = document.getElementById('culoare').value;

  if (isNaN(pozitie) || pozitie < 1 || pozitie > tabel.rows[0].cells.length + 1) {
      alert('Introduceți o poziție validă pentru coloană (între 1 și ' + (tabel.rows[0].cells.length + 1) + ')');
      return;
  }

  for (let i = 0; i < tabel.rows.length; i++) {
      const celulaNoua = tabel.rows[i].insertCell(pozitie - 1);
      
      if (i === 0) {
          celulaNoua.textContent = 'Detaliu nou';
          celulaNoua.style.fontWeight = 'bold';
          celulaNoua.style.backgroundColor = '#4CAF50';
          celulaNoua.style.color = 'white';
      } else {
          celulaNoua.textContent = '-';
          celulaNoua.style.backgroundColor = culoare;
      }
  }
}


function inregistreazaUtilizator() {
    const form = document.getElementById("form-inregistrare");
    const formData = new FormData(form);
    const user = {};
    formData.forEach((value, key) => {
        user[key] = value;
    });

    
    fetch("/api/utilizatori", {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(user)
    })
    .then(response => response.json())
    .then(data => {
        console.log("Răspuns server:", data);
        alert(data.mesaj);
    })
    .catch(error => {
        console.error("Eroare:", error);
        alert("A apărut o eroare!");
    });
}
