class Produs{
    constructor(id,nume,cantitate){
        this.id=id;
        this.nume=nume;
        this.cantitate=cantitate;
    }
}
function adaugaProdus()
{
    nume=document.getElementById("nume").value;
    cantitate=document.getElementById("cantitate").value;
    /*Produs(id,nume,cantitate);*/
    if(nume && cantitate)
    {

    }
    else
    {
        alert("Trebuie ambele câmpuri completate!");
    }
}