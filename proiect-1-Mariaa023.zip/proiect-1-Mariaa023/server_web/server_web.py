import socket
import os # pentru dimensiunea fisierului
import gzip
import io
import threading
import json
from urllib.parse import urlparse

# creeaza un server socket
serversocket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
# specifica ca serverul va rula pe portul 5678, accesibil de pe orice ip al serverului
serversocket.bind(('', 5678))
# serverul poate accepta conexiuni; specifica cati clienti pot astepta la coada
serversocket.listen(5)

def actiune(clientsocket):
    try:
        print('S-a conectat un client.')
        cerere = ''
        linieStart = ''
        while True:
            buf = clientsocket.recv(1024)
            if len(buf) < 1:
                break
            cerere = cerere + buf.decode()
            print('S-a citit mesajul: \n---------------------------\n' + cerere + '\n---------------------------')
            pozitie = cerere.find('\r\n')
            if (pozitie > -1 and linieStart == ''):
                linieStart = cerere[0:pozitie]
                print('S-a citit linia de start din cerere: ##### ' + linieStart + ' #####')
                break
        print('S-a terminat cititrea.')
        if linieStart == '':
            clientsocket.close()
            print('S-a terminat comunicarea cu clientul - nu s-a primit niciun mesaj.')
            return
        elementeLineDeStart = linieStart.split()
        metoda=elementeLineDeStart[0]
        numeResursaCeruta = urlparse(elementeLineDeStart[1]).path

        if metoda == "POST" and numeResursaCeruta == "/api/utilizatori":
            content_length = 0
            for linie in cerere.split('\r\n'):
                if linie.lower().startswith("content-length"):
                    content_length = int(linie.split(":")[1].strip())
        
            body = cerere[-content_length:].strip()

            try:
                utilizator = json.loads(body)
                fisier_utilizatori = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'continut', 'resurse', 'utilizatori.json')


                if os.path.exists(fisier_utilizatori):
                    with open(fisier_utilizatori, 'r', encoding='utf-8') as f:
                        utilizatori = json.load(f)
                else:
                    utilizatori = []
                utilizatori.append(utilizator)

                with open(fisier_utilizatori, 'w', encoding='utf-8') as f:
                    json.dump(utilizatori, f, indent=4, ensure_ascii=False)

                raspuns = {
                    "status": "succes",
                    "mesaj": "Utilizatorul a fost înregistrat cu succes."
                }
                raspuns_json = json.dumps(raspuns)

                headers = (
                    f"HTTP/1.1 200 OK\r\n"
                    f"Server: Server Web Python\r\n"
                    f"Content-Type: application/json; charset=utf-8\r\n"
                    f"Content-Length: {len(raspuns_json)}\r\n"
                    f"\r\n"
                )

                clientsocket.sendall(headers.encode('utf-8') + raspuns_json.encode('utf-8'))
                return

            except json.JSONDecodeError as e:
                print(f"[{threading.current_thread().name}] Eroare la parsarea JSON: {str(e)}")
                raspuns = {
                    "status": "eroare",
                    "mesaj": "Datele trimise nu sunt într-un format JSON valid."
                }
                raspuns_json = json.dumps(raspuns)

                headers = (
                    f"HTTP/1.1 400 Bad Request\r\n"
                    f"Server: Server Web Python\r\n"
                    f"Content-Type: application/json; charset=utf-8\r\n"
                    f"Content-Length: {len(raspuns_json)}\r\n"
                    f"\r\n"
                )

                clientsocket.sendall(headers.encode('utf-8') + raspuns_json.encode('utf-8'))

            except Exception as e:
                print(f"[{threading.current_thread().name}] Eroare: {str(e)}")
                raspuns = {
                    "status": "eroare",
                    "mesaj": f"A apărut o eroare la procesarea cererii: {str(e)}"
                }
                raspuns_json = json.dumps(raspuns)

                headers = (
                    f"HTTP/1.1 500 Internal Server Error\r\n"
                    f"Server: Server Web Python\r\n"
                    f"Content-Type: application/json; charset=utf-8\r\n"
                    f"Content-Length: {len(raspuns_json)}\r\n"
                    f"\r\n"
                )

                clientsocket.sendall(headers.encode('utf-8') + raspuns_json.encode('utf-8'))
                return
        if numeResursaCeruta == '/':
            numeResursaCeruta = '/index.html'
        numeFisier = '../continut' + numeResursaCeruta
        
        fisier = None
        try:
            # deschide fisierul pentru citire in mod binar
            fisier = open(numeFisier,'rb')
            content = fisier.read()

            # tip media
            numeExtensie = numeFisier[numeFisier.rfind('.')+1:]
            tipuriMedia = {
                'html': 'text/html; charset=utf-8',
                'css': 'text/css; charset=utf-8',
                'js': 'text/javascript; charset=utf-8',
                'png': 'image/png',
                'jpg': 'image/jpeg',
                'jpeg': 'image/jpeg',
                'gif': 'image/gif',
                'ico': 'image/x-icon',
                'xml': 'application/xml; charset=utf-8',
                'json': 'application/json; charset=utf-8'
            }
            tipMedia = tipuriMedia.get(numeExtensie,'text/plain; charset=utf-8')
            
            accepta_gzip = 'gzip' in cerere.lower() and numeExtensie in ['html', 'css', 'js', 'xml', 'json']
            
            # se trimite raspunsul
            clientsocket.sendall('HTTP/1.1 200 OK\r\n'.encode('utf-8'))
            if accepta_gzip:
                compressed_content = gzip.compress(content)
                clientsocket.sendall(f'Content-Length: {len(compressed_content)}\r\n'.encode('utf-8'))
                clientsocket.sendall(f'Content-Type: {tipMedia}\r\n'.encode('utf-8'))
                clientsocket.sendall('Content-Encoding: gzip\r\n'.encode('utf-8'))
                clientsocket.sendall('Server: My PW Server\r\n'.encode('utf-8'))
                clientsocket.sendall('\r\n'.encode('utf-8'))
                clientsocket.sendall(compressed_content)
            else:
                clientsocket.sendall(f'Content-Length: {len(content)}\r\n'.encode('utf-8'))
                clientsocket.sendall(f'Content-Type: {tipMedia}\r\n'.encode('utf-8'))
                clientsocket.sendall('Server: My PW Server\r\n'.encode('utf-8'))
                clientsocket.sendall('\r\n'.encode('utf-8'))
                clientsocket.sendall(content)
                
        except IOError:
            # daca fisierul nu exista trebuie trimis un mesaj de 404 Not Found
            msg = 'Eroare! Resursa ceruta ' + numeResursaCeruta + ' nu a putut fi gasita!'
            print(msg)
            clientsocket.sendall('HTTP/1.1 404 Not Found\r\n'.encode('utf-8'))
            clientsocket.sendall(f'Content-Length: {len(msg.encode('utf-8'))}\r\n'.encode('utf-8'))
            clientsocket.sendall('Content-Type: text/plain; charset=utf-8\r\n'.encode('utf-8'))
            clientsocket.sendall('Server: My PW Server\r\n'.encode('utf-8'))
            clientsocket.sendall('\r\n'.encode('utf-8'))
            clientsocket.sendall(msg.encode('utf-8'))

        finally:
            if fisier is not None:
                fisier.close()
            clientsocket.close()
            print('S-a terminat comunicarea cu clientul.')
            
    except Exception as e:
        print(f"Eroare neasteptata: {str(e)}")
        clientsocket.close()

print('#########################################################################')
print('Serverul asculta potentiali clienti.')

try:
    while True:
        (clientsocket, address) = serversocket.accept()
        client_thread = threading.Thread(target=actiune, args=(clientsocket,))
        client_thread.daemon = True
        client_thread.start()
        
except KeyboardInterrupt:
    print("\nServerul se inchide...")
finally:
    serversocket.close()